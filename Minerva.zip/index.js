 require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { 
  Client, 
  GatewayIntentBits, 
  Partials, 
  Events, 
  EmbedBuilder, 
  ActivityType, 
  Collection 
} = require('discord.js');

const {  ButtonBuilder, ActionRowBuilder, ButtonStyle } = require ('discord.js');


// Initialize Discord client with required intents
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.User],
});

// Tambahkan di bagian atas file setelah require lainnya
const colors = {
    reset: "\x1b[0m",
    cyan: "\x1b[36m",
    magenta: "\x1b[35m",
    green: "\x1b[32m",
    yellow: "\x1b[33m",
    bright: "\x1b[1m"
};
require('./handlers/security.js')(client);

const { connectToDatabase } = require('./mongodb');
const ReminderModel = require('./models/Reminder');
const answers = require('./answers.json');
// Hapus import Reminder yang duplikat
const prefix = "Z";
let lastCommandUser = null;

// Buat alias map
const commandAliases = {
  "r": "Report",
  "report": "Report",
  "m": "Mission",
  "mission": "Mission",
  "d": "Daily",
  "daily": "Daily",
  "w": "Weekly",
  "weekly": "Weekly",
  "tr": "Train",
  "train": "Train",
  "to": "Tower",
  "tower": "Tower",
  "tc": "Tc",
  "ch": "Challenge",
  "challenge": "Challenge"
};

// Fungsi normalisasi command
function normalizeCommand(input) {
  const lower = input.toLowerCase();
  return commandAliases[lower] || input;
}

// Improved command normalization
function normalizeCommandName(command) {
  return command
    .replace(/[^a-zA-Z0-9\s\-]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function capitalizeWords(str) {
  return str.replace(/\b\w/g, char => char.toUpperCase());
}

// Fungsi normalizeLabel yang hilang - TAMBAHKAN INI
function normalizeLabel(label) {
  const lowerLabel = label.toLowerCase();
  if (lowerLabel.includes('train')) return 'Train (N)';
  if (lowerLabel.includes('vote')) return 'Vote (N)';
  if (lowerLabel.includes('daily')) return 'Daily (N)';
  if (lowerLabel.includes('weekly')) return 'Weekly (N)';
  if (lowerLabel.includes('mission')) return 'Mission (N)';
  if (lowerLabel.includes('report')) return 'Report (N)';
  if (lowerLabel.includes('tower')) return 'Tower (N)';
  if (lowerLabel.includes('challenge')) return 'Challenge (N)';
  return capitalizeWords(label);
}

// Load commands dynamically
client.commands = new Collection();
function getAllCommandFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = entries.flatMap(entry => {
    const res = path.resolve(dir, entry.name);
    return entry.isDirectory() ? getAllCommandFiles(res) : res;
  });
  return files.filter(file => file.endsWith('.js'));
}

const commandFiles = getAllCommandFiles(path.join(__dirname, 'commands'));

for (const file of commandFiles) {
  try {
    const command = require(file);
    if (command.name && command.execute) {
      client.commands.set(command.name, command);
    } else {
      console.error(`[WARNING] The command at ${file} is missing a required "name" or "execute" property.`);
    }
  } catch (error) {
    console.error(`[ERROR] Failed to load command ${file}:`, error);
  }
}

client.on('messageDelete', require('./events/messageDelete').execute);

// Di file utama bot Anda (misal: index.js)
const welcome = require('./commands/welcome.js');
const goodbye = require('./commands/goodbye.js');

client.on('guildMemberAdd', welcome.execute);
client.on('guildMemberRemove', goodbye.execute);

// Bot presence activities
const activities = [
  { name: 'Dragon Ball', type: ActivityType.Watching },
  { name: 'Naruto Botto', type: ActivityType.Playing },
  { name: `${prefix}help for commands`, type: ActivityType.Listening },
];

let activityIndex = 0;

// Rotate activities every 30 seconds
setInterval(() => {
  if (client.user) {
    client.user.setPresence({
      status: 'online',
      activities: [activities[activityIndex % activities.length]],
    });
    activityIndex++;
  }
}, 30000);

// Load reminders from database
async function loadRemindersFromDB() {
  try {
    const all = await ReminderModel.find({});
    global.reminders = all.flatMap(user =>
      (user.reminders || []).map(reminder => ({
        ...reminder,
        userId: user.userId
      }))
    );
    console.log(`✅ Loaded ${global.reminders.length} reminders from database`);
  } catch (err) {
    console.error('❌ Failed to load reminders from DB:', err);
    global.reminders = [];
  }
}

// Enhanced Reminder System
global.reminderMap = new Map();

// Save reminders to database
async function saveRemindersToDB() {
  try {
    const remindersByUser = new Map();

    for (const reminder of global.reminders) {
      if (!remindersByUser.has(reminder.userId)) {
        remindersByUser.set(reminder.userId, []);
      }
      remindersByUser.get(reminder.userId).push(reminder);
    }

    for (const [userId, reminders] of remindersByUser.entries()) {
      await ReminderModel.updateOne(
        { userId },
        { $set: { userId, reminders } },
        { upsert: true }
      );
    }
  } catch (err) {
    console.error('❌ Failed to save reminders to DB:', err);
  }
}

async function addReminder(userId, channelId, commandType, label, timeMs) {
  // Normalize the command for comparison
  const normalizedCommand = normalizeCommandName(`${commandType} ${label}`);
  
  // Check for existing reminders
  const existingIndex = global.reminders.findIndex(r => 
    r.userId === userId && 
    r.normalizedCommand === normalizedCommand
  );

  const reminderMessage = `<@${userId}>: ${label} Ready!`;

  // Remove existing reminder if found
  if (existingIndex !== -1) {
    global.reminders.splice(existingIndex, 1);
  }

  const reminder = {
    userId,
    channelId,
    message: reminderMessage,
    time: Date.now() + timeMs,
    repeat: false,
    label,
    commandType,
    normalizedCommand,
    isUnique: ['Train', 'Vote'].includes(label)
  };

  global.reminders.push(reminder);
  await saveRemindersToDB();
  
  // Update reminder map
  if (!global.reminderMap.has(userId)) {
    global.reminderMap.set(userId, []);
  }
  global.reminderMap.get(userId).push(reminder);
  
  return reminder;
}

// Process reminders every minute
setInterval(async () => {
  const now = Date.now();
  const remindersToKeep = [];
  
  for (const reminder of global.reminders) {
    if (reminder.time <= now) {
      try {
        client.users.fetch(reminder.userId).then(user => {
          client.channels.fetch(reminder.channelId).then(channel => {
            channel.send({
              content: reminder.message,
              allowedMentions: { users: [reminder.userId] }
            });
          }).catch(console.error);
        }).catch(console.error);
        
        if (!reminder.repeat && global.reminderMap.has(reminder.userId)) {
          const updated = global.reminderMap.get(reminder.userId)
            .filter(r => r.normalizedCommand !== reminder.normalizedCommand);
          global.reminderMap.set(reminder.userId, updated);
        }
        
        if (reminder.repeat) {
          remindersToKeep.push({
            ...reminder,
            time: now + (reminder.time - (now - reminder.repeatInterval))
          });
        }
      } catch (error) {
        console.error('Error processing reminder:', error);
      }
    } else {
      remindersToKeep.push(reminder);
    }
  }
  
  global.reminders = remindersToKeep;
  await saveRemindersToDB();
}, 5000);

// Cooldown configurasi

const nCooldownMap = {
  'n m': { duration: 60 * 1000, label: 'Mission', type: 'n' },
  'n w': { duration: 7 * 60 * 60 * 60 * 1000, label: 'Weekly', type: 'n' },
  'n r': { duration: 10 * 60 * 1000, label: 'Report', type: 'n' },
  'n d': { duration: 20 * 60 * 60 * 1000, label: 'Daily', type: 'n' },
  'n ch': { duration: 30 * 60 * 1000, label: 'Challenge', type: 'n' },
  'n to': { duration: 6 * 60 * 60 * 1000, label: 'Tower', type: 'n' },
  'n tr': { 
    duration: 60 * 60 * 1000, 
    label: 'Train (N)',
    type: 'n',
    unique: true
  },
  'n tr basic': { 
    duration: 60 * 60 * 1000, 
    label: 'Train Basic (N)', 
    type: 'n',
    unique: true
  },
  'n tr advanced': { 
    duration: 60 * 60 * 1000, 
    label: 'Train Advanced (N)', 
    type: 'n',
    unique: true
  },
  'n tr expert': { 
    duration: 60 * 60 * 1000, 
    label: 'Train Expert (N)', 
    type: 'n',
    unique: true
  },
  'n tr pro': { 
    duration: 60 * 60 * 1000, 
    label: 'Train Pro (N)', 
    type: 'n',
    unique: true
  }
};

const labelMap = {
  'mission': 'n m',
  'weekly': 'n w',
  'challange': 'n ch',
  'report': 'n r',
  'tower': 'n to',
  'train basic': 'n tr basic',
  'train advanced': 'n tr advanced',
  'train expert': 'n tr expert',
  'train pro': 'n tr pro'
};

// Message handler
client.on('messageCreate', async (message) => {
  if (message.author.bot) {
    await handleBotMessage(message);

  
    const duelTracker = client.commands.get('duelTracker');
    if (duelTracker) duelTracker.execute(message);

    return;
  }

  const content = message.content.trim();

  // Command dengan prefix
  if (content.startsWith(prefix)) {
    await handleCommand(message, content);
  }

  await handleManualCommands(message, content.toLowerCase());
});

async function handleBotMessage(message) {
  const embed = message.embeds[0];
  // --- NEW FIX: Tangkap balasan plain text Naruto Botto (contoh: "Wait 1d 5h 49m 33s for your next weekly") ---
  if (message.author.username.includes("Naruto Botto") && !embed) {
    const match = message.content.match(/Wait\s+([0-9dhms\s]+)\s+(?:before|for)\s+your\s+next\s+([a-zA-Z]+)/i);

    if (match && lastCommandUser) {
      const timeMs = parseCooldown(match[1]);
      const commandType = 'n';
      const commandLabel = normalizeLabel(match[2].trim());

      await addReminder(
        lastCommandUser.id,        // pemilik command (bukan Naruto)
        message.channel.id,
        commandType,               // 'n'
        commandLabel,              // 'Report'
        timeMs
      );
      return; // selesai di sini untuk pesan plain text
    }
  }

  if (!embed) return;

  // === Cooldowns dari Naruto Botto ===
  if ((embed.title && embed.title.toLowerCase().includes('cooldowns')) || embed.description) {
    const content = embed.description || embed.fields?.map(f => `${f.name}\n${f.value}`).join('\n') || '';
    const lines = content.split('\n');

    for (const line of lines) {
      let commandLabel, timeMs;

      // Format 1: --- Weekly (1d 20h ...)
      let match = line.match(/---\s*([^\(]+)\s*\(([^)]+)\)/i);
      if (match) {
        commandLabel = match[1].trim();
        timeMs = parseCooldown(match[2]);
      }

      // Format 2: Wait 1d 6h 32m for your next weekly
      if (!match) {
        match = line.match(/Wait\s+([0-9dhms\s]+)\s+for your next\s+([a-zA-Z]+)/i);
        if (match) {
          timeMs = parseCooldown(match[1]);
          commandLabel = match[2].trim(); // misal "weekly"
          commandLabel = commandLabel.charAt(0).toUpperCase() + commandLabel.slice(1); // kapitalin
        }
      }

      if (!match || !lastCommandUser) continue;

      const commandType = 'n';
      let finalLabel = normalizeLabel(commandLabel);

      await addReminder(
        lastCommandUser.id,
        message.channel.id,
        commandType,
        finalLabel,
        timeMs
      );
    }
  }

  // === Auto-answer quiz Naruto Botto (biarkan tetap) ===
  if (message.author.username.includes('Naruto Botto') || message.author.id === '770100332998295572') {
    let embedText = '';
      
    if (embed.description) embedText += embed.description + '\n';
    if (embed.title) embedText += embed.title + '\n';
    if (embed.fields?.length) {
      for (const field of embed.fields) {
        embedText += (field.name || '') + '\n' + (field.value || '') + '\n';
      }
    }

    
// Jawab quiz otomatis pakai answers.json (versi fleksibel + cari nomor opsi)
if (embed.description || embed.fields?.length) {
  let content = "";
  if (embed.description) content += embed.description + "\n";
  if (embed.fields?.length) {
    for (const f of embed.fields) {
      content += (f.name || "") + "\n" + (f.value || "") + "\n";
    }
  }
  const lines = content.split('\n').filter(l => l.trim() !== '');
  const rawQuestion = lines[0]; // baris pertama = pertanyaan
  const options = lines.slice(1); // sisanya = opsi jawaban

  // Normalisasi pertanyaan dari Naruto Botto
  const normalizedQuestion = rawQuestion
    .toLowerCase()
    .replace(/[^\w\s]/g, '') // hapus tanda baca
    .trim();

  let correctAnswer = null;
  for (const key in answers) {
    const normalizedKey = key.toLowerCase().replace(/[^\w\s]/g, '').trim();
    if (normalizedKey === normalizedQuestion) {
      correctAnswer = answers[key];
      break;
    }
  }

  if (correctAnswer) {
    // cari jawaban benar ada di opsi nomor berapa
    let optionNumber = null;
    options.forEach((opt, idx) => {
 // const cleanOpt = opt.replace(/^\d+[\).\s-]*/, '').trim().toLowerCase();
const cleanOpt = opt.replace(/^\d+\s*/, '').trim().toLowerCase();

// cek apakah jawaban benar ada di opsi
if (cleanOpt.includes(correctAnswer.toLowerCase())) {
  optionNumber = idx + 1;
}
});


    const triviaEmbed = new EmbedBuilder()
      .setColor(Math.floor(Math.random() * 16777215).toString(16))
      .setTitle("📙📘📗 Naruto Botto 📚");

    // Map numbers
const blueNumbers = ['1️⃣', '2️⃣', '3️⃣'];

if (optionNumber) {
  const emojiNum = blueNumbers[optionNumber - 1] || `[${optionNumber}]`;
  triviaEmbed
    .setColor(Math.floor(Math.random() * 16777215).toString(16))
    .setTitle("👺 Naruto Botto 📚")
    .setDescription(`__Answer__ : **${emojiNum} ${correctAnswer}**`);
} else {
  triviaEmbed
    .setColor(Math.floor(Math.random() * 16777215).toString(16))
    .setTitle("👺 Naruto Botto 📚")
    .setDescription(`__Answer__ : **${correctAnswer}**`);
}


    await message.channel.send({ embeds: [triviaEmbed] });
  }
}

// === Deteksi Report dari Naruto Botto (versi sederhana: hanya 1 button "3 Grey Gate") ===
const reportRegex = /group of (\d+)\s+suspicious individuals in (black|grey|white) clothes (?:in|by) the (?:dango shop|forest|gate)/i;
const match = embedText.match(reportRegex);

if (match) {
  const jumlah = match[1];
  const warna = match[2].charAt(0).toUpperCase() + match[2].slice(1);
  // ambil lokasi dari teks (dango shop, forest, gate)
  const lokasiMatch = embedText.match(/(?:in|by) the (dango shop|forest|gate)/i);
  const lokasi = lokasiMatch ? lokasiMatch[1].replace(" shop", "").charAt(0).toUpperCase() + lokasiMatch[1].replace(" shop", "").slice(1) : "Gate";

  const label = `${jumlah} ${warna} ${lokasi}`; // contoh: "3 Grey Gate"

  let style = ButtonStyle.Secondary; // default

if (warna.toLowerCase() === "black") style = ButtonStyle.Danger;     // merah
else if (warna.toLowerCase() === "grey") style = ButtonStyle.Primary; // biru terang
else if (warna.toLowerCase() === "white") style = ButtonStyle.Success; // hijau

const button = new ButtonBuilder()
  .setCustomId(`report_${Date.now()}`)
  .setLabel(`${jumlah} ${warna} ${lokasi}`)
  .setStyle(style)
  // .setDisabled(true);



  const row = new ActionRowBuilder().addComponents(button);

  await message.channel.send({
    components: [row]
  });
}




  }
}

async function handleCommand(message, content) {
  lastCommandUser = message.author;
  const args = content.slice(prefix.length).trim().split(/\s+/);
  const commandName = args[0]?.toLowerCase();
  
  const command = client.commands.get(commandName);

const validCommands = [
  "about", "avatar", "ban", "calc", "coin", "converter", "dp",
  "duelTracker", "gakatsuki", "gdragonball", "gnaruto", "goodbye",
  "hapusremind", "help", "img1", "img2", "kick", "lock", "mute",
  "ping", "ping2", "purge", "remindrepeat", "remindrepeat", "rules",
  "server", "slot", "steal", "tenor", "tictactoe", "unlock",
  "user", "warn", "welcome",
  "8ball", "WordScramble", "fact", "friendship", "game", "getnumber20",
  "joke", "meme", "quote", "randomnumber", "roll", "say", "wordAssociation",
  "assassinate", "hack", "howgay", "roast",
  "binary", "button", "emoji", "password"
];

if (!command) {
  if (!validCommands.includes(commandName)) return; // diam aja kalau bukan command yang dikenal
  return message.reply(`❌ Unknown command\nCommands ${commandName} no found. Use \`${prefix}help\` to see a list of commands.`);
}


  try {
    await command.execute(message, args.slice(1));
  } catch (error) {
    console.error(`Error executing command ${commandName}:`, error);
    
    const errorEmbed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle('❌ Error')
      .setDescription('Terjadi kesalahan saat menjalankan perintah.');
      
    message.reply({ embeds: [errorEmbed] });
  }
}

async function handleManualCommands(message, lowerContent) {
  const args = message.content.trim().split(/\s+/);
  const baseCommand = args.slice(0, 2).join(' ').toLowerCase();

  // Kalau command Naruto (n m, n w, n d, n to, dll)
  if (nCooldownMap[baseCommand]) {
    const data = nCooldownMap[baseCommand];
    lastCommandUser = message.author;

    // 🔥 Buat reminder langsung (pakai default cooldown dari map)
    await addReminder(
      message.author.id,
      message.channel.id,
      data.type,
      normalizeLabel(data.label),
      data.duration
    );
  }

 

  // Respon kalau user mention bot
  if (message.mentions.has(client.user)) {
    const helpEmbed = new EmbedBuilder()
      .setColor(0x0099FF)
      .setTitle('🤖 Bot Help')
      .setDescription(`Halo! Used \`${prefix}help\` To see the list of commands available.`);
    return message.reply({ embeds: [helpEmbed] });
  }
}

// Reminder command
client.commands.set('reminder', {
  name: 'reminder',
  description: 'Kelola reminder',
  aliases: ['remind', 'r'],
  async execute(message, args) {
    if (args[0] === 'list') {
      return await listReminders(message);
    }
    
    if (args[0] === 'clear') {
      return await clearReminders(message);
    }
    
    return await createReminder(message, args);
  }
});

async function listReminders(message) {
  // Get unique reminders for the user
  const userReminders = [];
  const seenCommands = new Set();
  
  for (const reminder of global.reminders) {
    if (reminder.userId === message.author.id && !seenCommands.has(reminder.normalizedCommand)) {
      userReminders.push(reminder);
      seenCommands.add(reminder.normalizedCommand);
    }
  }
  
  // Sort by time
  userReminders.sort((a, b) => a.time - b.time);

  if (userReminders.length === 0) {
    const emptyEmbed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('📭 There is no active reminder')
      .setDescription('You dont have an active reminder at this time.');
    return message.channel.send({ embeds: [emptyEmbed] });
  }

  const reminderList = userReminders.map((r, i) => {
    const timeLeft = Math.max(0, r.time - Date.now());
    const { days, hours, minutes, seconds } = formatTime(timeLeft);
    
    // Format waktu dengan koma sebagai pemisah
    const timeParts = [
      days ? `${days}d` : '',
      hours ? `${hours}h` : '',
      minutes ? `${minutes}m` : '',
      seconds ? `${seconds}s` : ''
    ].filter(Boolean);
    
    const timeStr = timeParts.join(', ');

    return `${i + 1}. ${r.label} (in ${timeStr})`;
  }).join('\n');

  const listEmbed = new EmbedBuilder()
    .setColor(0x00aaff)
    .setTitle(`📋 Reminder List - ${message.author.username}`)
    .setDescription(reminderList)
    .setFooter({ text: `Total: ${userReminders.length} reminder` })
    .setTimestamp();

  return message.channel.send({ embeds: [listEmbed] });
}

async function clearReminders(message) {
  try {
    global.reminders = global.reminders.filter(r => r.userId !== message.author.id);
    global.reminderMap.delete(message.author.id);

    await ReminderModel.deleteOne({ userId: message.author.id });

    return message.channel.send('✅ All your reminder has been deleted.');
  } catch (err) {
    console.error('❌ Failed to remove the reminder:', err);
    return message.channel.send('❌ An error occurs when removing the reminder.');
  }
}

async function createReminder(message, args) {
  const timeArg = args[0];
  if (!timeArg) {
    const helpEmbed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('⏰ Format Reminder')
      .setDescription([
        `Use the format: \`${prefix}reminder or ${prefix}r <time> <message>\``,
        'Example:',
        `\`${prefix}reminder 1d2h30m drink water\``,
        `\`${prefix}reminder 30m rest\``,
        'Time Format: `d` (day), `h` (hour), `m` (minutes)'
      ].join('\n'));
    return message.channel.send({ embeds: [helpEmbed] });
  }

  const timeStr = args[0].replace(/\s+/g, '').toLowerCase();
  const match = timeStr.match(/(?:(\d+)\s*(d|day))?\s*(?:(\d+)\s*(h|hour))?\s*(?:(\d+)\s*(m|minute))?/);

  if (!match) {
    const errorEmbed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('❌ Time Format no Valid')
      .setDescription([
        'Time format is not recognized. Example:',
        `\`${prefix}reminder 1d4h25m your message\``,
        `\`${prefix}reminder 1day4hour25minutes your message\``
      ].join('\n'));
    return message.channel.send({ embeds: [errorEmbed] });
  }

  const days = parseInt(match[1]) || 0;
  const hours = parseInt(match[3]) || 0;
  const minutes = parseInt(match[5]) || 0;
  
  if (days === 0 && hours === 0 && minutes === 0) {
    const errorEmbed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('❌ Invalid Time')
      .setDescription('Time format is not recognized.');
    return message.channel.send({ embeds: [errorEmbed] });
  }

  const timeMs = (days * 24 * 60 + hours * 60 + minutes) * 60 * 1000;
  const reminderMsg = args.slice(1).join(' ');

  if (!reminderMsg) {
    const errorEmbed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('❌ Empty message')
      .setDescription('Please include a message for reminder.');
    return message.channel.send({ embeds: [errorEmbed] });
  }

  // Check for duplicate reminders
  const normalizedNewMsg = normalizeCommandName(`manual ${reminderMsg}`);
  const isDuplicate = global.reminders.some(r => 
    r.userId === message.author.id && 
    r.normalizedCommand === normalizedNewMsg
  );

  if (isDuplicate) {
    const duplicateEmbed = new EmbedBuilder()
      .setColor(0xffbb33)
      .setTitle('⚠️ Reminder already exists')
      .setDescription('you already have a reminder with the same message.');
    return message.channel.send({ embeds: [duplicateEmbed] });
  }

  // Create new reminder
  const reminder = {
    userId: message.author.id,
    channelId: message.channel.id,
    message: `<@${message.author.id}>: ${reminderMsg}`,
    time: Date.now() + timeMs,
    repeat: false,
    label: reminderMsg,
    commandType: 'manual',
    normalizedCommand: normalizedNewMsg
  };

  global.reminders.push(reminder);
  
  // Update in-memory map
  if (!global.reminderMap.has(message.author.id)) {
    global.reminderMap.set(message.author.id, []);
  }
  global.reminderMap.get(message.author.id).push(reminder);
  
  // Save to database
  await saveRemindersToDB();

  const timeStrFormatted = [
    days > 0 ? `${days} day` : '',
    hours > 0 ? `${hours} hour` : '',
    minutes > 0 ? `${minutes} minute` : ''
  ].filter(Boolean).join(' ');

  const successEmbed = new EmbedBuilder()
    .setColor(0x00cc99)
    .setTitle('⏰ Reminder is stored')
    .addFields(
      { name: 'Message', value: reminderMsg, inline: true },
      { name: 'Time', value: timeStrFormatted, inline: true },
      { name: 'Aktive to', value: `<t:${Math.floor(reminder.time/1000)}:R>`, inline: false }
    )
    .setTimestamp();

  return message.channel.send({ embeds: [successEmbed] });
}

// Helper functions
function parseCooldown(str) {
  const d = (str.match(/(\d+)\s*d/) || [])[1] || 0;
  const h = (str.match(/(\d+)\s*h/) || [])[1] || 0;
  const m = (str.match(/(\d+)\s*m/) || [])[1] || 0;
  const s = (str.match(/(\d+)\s*s/) || [])[1] || 0;
  return (parseInt(d) * 86400 + parseInt(h) * 3600 + parseInt(m) * 60 + parseInt(s)) * 1000;
}

function formatTime(ms) {
  let s = Math.floor(ms / 1000);
  const days = Math.floor(s / 86400);
  s %= 86400;
  const hours = Math.floor(s / 3600);
  s %= 3600;
  const minutes = Math.floor(s / 60);
  const seconds = s % 60;
  
  return { days, hours, minutes, seconds };
}

client.once(Events.ClientReady, async () => {
    console.log(`\n${colors.green}${colors.bright}✔${colors.reset} Bot is ready as ${colors.cyan}${client.user.tag}${colors.reset}`);
    
    try {
        await connectToDatabase();
        console.log(
            `${colors.cyan}[ ${colors.magenta}DATABASE${colors.cyan} ]` + 
            `${colors.reset} ${colors.green}${colors.bright}MongoDB connected successfully` +
            `${colors.reset} ${colors.yellow}✓${colors.reset}`
        );
        await loadRemindersFromDB();
    } catch (error) {
        console.log(`${colors.red}[ ERROR ]${colors.reset} Failed to connect to MongoDB`);
    }
});

// Error handling
process.on('unhandledRejection', error => {
  console.error('Unhandled promise rejection:', error);
});

client.login(process.env.DISCORD_TOKEN);
