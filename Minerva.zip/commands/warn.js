module.exports = {
  name: 'warn',
  description: 'Warn member',
  async execute(message, args) {
const memberWarn = message.mentions.members.first();
      if (memberWarn) {
        message.reply(`${memberWarn.user.tag} has been warn.`);
      } else {
        message.reply('Tag members you want to be warn.');
      }
}
};
