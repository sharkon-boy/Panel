const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'avatar',
  aliases: ['av', 'pfp', 'ava'], // alias seperti Zav, Zap, dll bisa ditambahkan di sini
  description: 'Menampilkan avatar pengguna atau pengguna yang disebut',
  async execute(message, args) {
    const target = message.mentions.users.first() || message.author;

    const embed = new EmbedBuilder()
      .setTitle(`Avatar dari ${target.username}`)
      .setImage(target.displayAvatarURL({ size: 1024, dynamic: true }))
      .setColor('Blue')
      .setFooter({ text: `Diminta oleh ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    message.reply({ embeds: [embed] });
  }
};
