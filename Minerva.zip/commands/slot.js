const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'slot',
  description: 'Play your slot machine and test your luck!',
  async execute(message) {
    const symbols = ['🍒', '🍋', '🔔', '💎', '7️⃣', '🍇'];
    const spin = () => symbols[Math.floor(Math.random() * symbols.length)];

    // Kirim pesan loading (simulasi "rolling")
    const loadingEmbed = new EmbedBuilder()
      .setTitle('**   **  🎰 | Slot')
      .setDescription('The engine is spinning...')
      .setColor('Yellow');

    const sentMessage = await message.reply({ embeds: [loadingEmbed] });

    // Delay 2 detik untuk simulasi
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Hasil slot setelah delay
    const row1 = [spin(), spin(), spin()];
    const row2 = [spin(), spin(), spin()];
    const row3 = [spin(), spin(), spin()];

    const slotDisplay = `
\`\`\`
| ${row1.join(' ')} |
| ${row2.join(' ')} | <—
| ${row3.join(' ')} |
\`\`\`
`;

    let resultText;
    const [a, b, c] = row2;

    if (a === b && b === c) {
      resultText = '🎉 **JACKPOT! You win big!**';
    } else if (a === b || b === c || a === c) {
      resultText = '😄 **Small win!** Two symbols are suitable.';
    } else {
      resultText = '😢 **Lost. Try again OK!**';
    }

    const resultEmbed = new EmbedBuilder()
      .setTitle(' **   ** 🎰 | Slot ')
      .setDescription(slotDisplay + resultText)
      .setColor(a === b && b === c ? 'Green' : a === b || b === c || a === c ? 'Orange' : 'Red')
      .setFooter({ text: `Duration: 1 second ${message.author.username}`, 

iconURL: message.author.displayAvatarURL() 
})
.setThumbnail(message.guild.iconURL({ dynamic: true }));

    await sentMessage.edit({ embeds: [resultEmbed] });
  },
};
