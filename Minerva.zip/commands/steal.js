const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'steal',
  description: 'Ambil URL emoji custom, stiker, atau avatar user',
  async execute(message, args) {
    setTimeout(() => message.delete().catch(console.error), 3000);

    let emojiInput = args[0];
    let targetMessage = null;

    // Jika tidak ada input, ambil pesan sebelumnya
    if (!emojiInput) {
      const messages = await message.channel.messages.fetch({ limit: 2 });
      const previousMessage = [...messages.values()].find(m => m.id !== message.id);
      if (!previousMessage) return;

      targetMessage = previousMessage;

      // Ambil emoji dari konten jika ada
      const emojiRegex = /<(a?):(\w+):(\d+)>/;
      const match = previousMessage.content.match(emojiRegex);
      if (match) {
        emojiInput = match[0];
      }

      // Atau ambil stiker jika ada
      if (!emojiInput && previousMessage.stickers.size > 0) {
        const sticker = previousMessage.stickers.first();
        const embed = new EmbedBuilder()
          .setColor('Purple')
          .setDescription(`**${message.author.username} stole sticker from ${previousMessage.author.username}**`)
          .setImage(sticker.url);
        const reply = await message.reply({ embeds: [embed] });
        return setTimeout(() => reply.delete().catch(console.error), 15000);
      }
    }

    const emojiRegex = /<(a?):(\w+):(\d+)>/;
    const match = emojiInput?.match(emojiRegex);

    // Handle custom emoji
    if (match) {
      const isAnimated = match[1] === 'a';
      const name = match[2];
      const id = match[3];
      const url = `https://cdn.discordapp.com/emojis/${id}.${isAnimated ? 'gif' : 'png'}`;

      let originalPoster = 'unknown';
      if (targetMessage) {
        originalPoster = targetMessage.author.username;
      } else if (message.reference?.messageId) {
        try {
          const referenced = await message.channel.messages.fetch(message.reference.messageId);
          originalPoster = referenced.author.username;
        } catch (err) {
          console.error(err);
        }
      }

      const embed = new EmbedBuilder()
        .setColor('Green')
        .setDescription(`**${message.author.username} stole from ${originalPoster}**\n${emojiInput}`)
        .setImage(url);
      const reply = await message.reply({ embeds: [embed] });
      return setTimeout(() => reply.delete().catch(console.error), 15000);
    }

    // Jika mention user untuk avatar
    const target = message.mentions.users.first();
    if (target) {
      const embed = new EmbedBuilder()
        .setColor('Blue')
        .setDescription(`**${message.author.username} stole avatar from ${target.username}**`)
        .setImage(target.displayAvatarURL({ size: 1024, dynamic: true }));
      const reply = await message.reply({ embeds: [embed] });
      return setTimeout(() => reply.delete().catch(console.error), 15000);
    }

    // Jika semua gagal
    const warning = await message.reply({
      embeds: [
        new EmbedBuilder()
          .setColor('Red')
          .setDescription('**No emoji or sticker found.**')
      ]
    });
    setTimeout(() => warning.delete().catch(console.error), 5000);
  }
};
