const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'calc',
  description: 'Kalkulator',
  execute(message, args) {
    if (args.length < 1) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle('Command : Calc')
            .setDescription('Format: `Zcalc <ekspresi>` Exp: `Zcalc 6+7+7-7` or `Zcalc √512`')
            .setColor('Red')
        ]
      });
    }

    let input = args.join('').trim();
    let hasil;
    let error = false;

    // Hilangkan "=" di akhir jika ada
    if (input.endsWith('=')) {
      input = input.slice(0, -1);
    }

    try {
      // Tangani akar √ atau sqrt
      if (input.startsWith('√')) {
        const num = parseFloat(input.slice(1));
        if (isNaN(num)) throw new Error('Invalid number.');
        hasil = Math.sqrt(num);
      } else if (input.toLowerCase().startsWith('sqrt')) {
        const num = parseFloat(input.slice(4));
        if (isNaN(num)) throw new Error('Angka tidak valid.');
        hasil = Math.sqrt(num);
      } else if (/^[0-9+\-*/^().mod ]+$/i.test(input)) {
        // Format bebas tanpa spasi

        // Ganti ^ jadi ** untuk pangkat
        input = input.replace(/\^/g, '**');

        // Ganti mod jadi %
        input = input.replace(/mod/gi, '%');

        // Hitung
        hasil = Function(`"use strict"; return (${input})`)();
      } else if (args.length === 3 || args.length === 2) {
        // Format lama dengan spasi (angka operator angka)
        let angka1, operator, angka2;

        if (args[0] === '√' || args[0].toLowerCase() === 'sqrt') {
          angka1 = parseFloat(args[1]);
          if (isNaN(angka1)) throw new Error('Invalid numbers for roots.');
          hasil = Math.sqrt(angka1);
        } else {
          angka1 = parseFloat(args[0]);
          operator = args[1].toLowerCase();
          angka2 = parseFloat(args[2]);

          if (isNaN(angka1) || isNaN(angka2)) throw new Error('Angka tidak valid.');

          switch (operator) {
            case '+': hasil = angka1 + angka2; break;
            case '-': hasil = angka1 - angka2; break;
            case '*': hasil = angka1 * angka2; break;
            case '/':
              if (angka2 === 0) throw new Error('Cannot be divided by zero.');
              hasil = angka1 / angka2;
              break;
            case 'mod': hasil = angka1 % angka2; break;
            case '^': hasil = Math.pow(angka1, angka2); break;
            default: throw new Error('Operator unknow.');
          }
        }
      } else {
        throw new Error('Format invalid.');
      }
    } catch (err) {
      hasil = err.message;
      error = true;
    }

    const embed = new EmbedBuilder()
      .setTitle('Calculation results')
      .addFields(
        { name: 'Input', value: `\`${args.join(' ')}\`` },
        { name: error ? 'Fault' : 'Results', value: `\`${hasil}\`` }
      )
      .setColor(error ? 'Red' : 'Green');

    message.reply({ embeds: [embed] });
  }
};
