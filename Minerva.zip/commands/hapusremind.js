const fs = require('fs');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'hapusremind',
  aliases: ['hr', 'hapusreminder', 'delete', 'deleteremind', 'dl'],
  description: 'Delete all your reminders.',
  async execute(message, args) {
    const userId = message.author.id;

    // Hapus semua reminder milik user ini
    global.reminders = global.reminders.filter(r => r.userId !== userId);
    global.reminderMap.set(userId, []);

    // Simpan ulang ke file
    fs.writeFileSync('reminders.json', JSON.stringify(global.reminders, null, 2));

    // Buat embed sebagai konfirmasi
    const embed = new EmbedBuilder()
      .setColor(0xff4444)
      .setTitle('Delete Reminder')
      .setDescription(`<@${userId}>, All your reminder has been successfully deleted.`)
      .setFooter({ text: 'Use the Zreminder List to see the remaining reminder active period.' });

    message.reply({ embeds: [embed] });
  }
}
