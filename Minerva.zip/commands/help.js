const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');

module.exports = {
  name: 'help',
  description: 'Menampilkan semua kategori command',
  async execute(message) {
    const pages = [

      // 🌟 Halaman Utama
      new EmbedBuilder()
        .setTitle('📄 Help Menu')
        .setColor(0x00AE86)
        .setFooter({
          text: `${message.author.username}`,
          iconURL: message.author.displayAvatarURL()
        })
        .setTimestamp()
        .setImage('https://media.discordapp.net/attachments/1235101083127255040/1391427613041492099/IMG_20250706_213534.jpg')
        .setDescription(`
**👋 Welcome to The Tank Crew**
A versatile Discord bot with features for your community.

Server:
╔═━┅┄⟞ ★ ✧ ✦ ✧ ★ ⟝┄┉━═╗
[Join The Tank Crew](https://discord.gg/JaTHEWMb5h)
╚═━┅┄⟞ ★ ✧ ✦ ✧ ★ ⟝┄┉━═╝

Bot Prefix: **Z**

*Navigate through categories using the buttons below*
`),

      // 📄 Page 1 - Umum
      new EmbedBuilder()
        .setTitle('📄 Page 1 - Umum')
        .setColor(0x00AE86)
        .setDescription(`
**Umum**
> Zping   Zkick 
> Zavatar Zban
> Zabout  Zmute
> Zserver Zwarn
> Zuser   Zping2
`)
        .setImage('https://c.tenor.com/yt6DIuh68fsAAAAC/tenor.gif')
        .setFooter({ text: "Use ◀ or ▶ to navigate pages" }),

      // ⚙️ Page 2 - Utility and Troll
      new EmbedBuilder()
        .setTitle('⚙️ Page 2 - Utility and Troll')
        .setColor(0x00AE86)
        .setDescription(`
**Utility and Troll**
> Zassassinate Zbinary
> Zhowgay       Zemoji
> Zroast        Zbutton
> Zhack         Zpassword
> Zconverter    Zsay
`)
        .setImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT22c9AH1hn_RgMLYSB86sWNd4YGORKP7a0QNHhXg2uGg&s=10')
        .setFooter({ text: "Use ◀ or ▶ to navigate pages" }),

      // ⏰ Page 3 - Reminder
      new EmbedBuilder()
        .setTitle('⏰ Page 3 - Reminder')
        .setColor(0x00AE86)
        .setDescription(`
**Reminder Commands**
> Zreminder 
> Zremindrepeat 
> Zreminder list 
> Zdeleteremind
`)
        .setImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUy065C1BJ8oIyljAGwjqoAUaZD5jKiWS3oZPGL0l00FJ8YkidgLgH8Fw&s=10')
        .setFooter({ text: "Use ◀ or ▶ to navigate pages" }),

      // ⚔️ Page 4 - Commands
      new EmbedBuilder()
        .setTitle('⚔️ Page 4 - Commands')
        .setColor(0x00AE86)
        .setDescription(`
**Commands**
> Zpurge Zmeme
> Ztenor Zfact
> Zsteal Zjoke
> Zcalc  Zgame
> Zgetnumber20 
> Zrandomnumber
> ZwordAssociation
> ZwordScramble
`)
        .setImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQh-oudUiHNZBD5xtbARq_wsXaSHvl_Eepzb06KpGtEcA&s=10')
        .setFooter({ text: "Use ◀ or ▶ to navigate pages" }),

      // 🎮 Page 5 - Games
      new EmbedBuilder()
        .setTitle('🎮 Page 5 - Games')
        .setColor(0x00AE86)
        .setDescription(`
**Games**
> Zslot - Game Slot
> Z8ball - Game 8ball
> Zroll - Game Roll 
> Zcoin - Game Coinflip
> Ztictactoe - Game Tictactoe
> Zlock or Zunlock Channels
> Zgallerynaruto Zgalleryakatsuki
`)
        .setImage('https://media.tenor.com/QhlI182lY8cAAAAi/sasuke-uchiha-sasuke.gif')
        .setFooter({ text: "Use ◀ or ▶ to navigate pages" })
    ];

    // 🎛️ Tombol navigasi
    let currentPage = 0;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('prev')
        .setLabel('◀')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('▶')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('close')
        .setLabel('❌')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await message.reply({
      embeds: [pages[currentPage]],
      components: [row]
    });

    // ⏱️ Kolektor tombol
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 60000 // 1 menit
    });

    collector.on('collect', i => {
      if (i.user.id !== message.author.id) {
        return i.reply({
          content: 'Hanya pengguna yang memanggil command ini yang bisa mengontrol.',
          ephemeral: true
        });
      }

      if (i.customId === 'prev') {
        currentPage = (currentPage - 1 + pages.length) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'next') {
        currentPage = (currentPage + 1) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'close') {
        i.update({ content: 'Dibatalkan.', embeds: [], components: [] });
        collector.stop();
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};
