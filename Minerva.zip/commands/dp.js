const { EmbedBuilder } = require('discord.js');
const Duel = require('../models/Duel');

module.exports = {
  name: 'dp',
  description: 'Menampilkan statistik duel user seperti Duel Tracker',
  async execute(message) {
    const user = message.mentions.users.first() || message.author;

    const duelData = await Duel.findOne({ userId: user.id });

    if (!duelData) {
      return message.channel.send(`⚠️ ${user.username} belum pernah duel.`);
    }

    const { victories = 0, duels = 0 } = duelData;
    const winRatio = duels > 0 ? ((victories / duels) * 100).toFixed(2) : 0;

    const embed = new EmbedBuilder()
      .setColor(0xffff00)
      .setDescription([
        `**${user.id} — profile**`,
        '',
        '**STATS**',
        `♦ **VICTORIES:** ${victories}`,
        `♦ **DUELS:** ${duels}`,
        `♦ **WIN RATIO:** ${winRatio}%`,
        '',
        '**USER**',
        `<@${user.id}>`
      ].join('\n'))
      .setTimestamp();

    await message.channel.send({ embeds: [embed] });
  }
};
