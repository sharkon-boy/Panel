const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'img2',
  description: 'Cek img2 bot',
  execute(message) {
    const embed = new EmbedBuilder()
      .setColor(0xFF8C00)

      .setImage('https://c.tenor.com/QKZdivUlu7QAAAAd/tenor.gif');

    message.channel.send({ embeds: [embed] });
  }
};
