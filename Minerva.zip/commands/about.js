const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'about',
  description: 'Information about this bot',
  execute(message) {
    const embed = new EmbedBuilder()
      .setTitle('🤖 About this Bot')
      .setDescription('Multifunctional bot for discord: general, moderation, reminder and command..')
      .addFields(
        { name: 'Author', value: '愛ᴛᴇɴɢᴜ', inline: true },
        { name: 'Versi', value: '1.0.0', inline: true },
        { name: 'Library', value: 'discord.js v14', inline: true }
      )
      .setColor('Blue')
      .setFooter({ text: `Request by: ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) });

    message.reply({ embeds: [embed] });
  }
};
