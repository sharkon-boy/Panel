const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'purge',
  aliases: ['p', 'purge'],
  description: 'Delete a number of messages from the channel',
  async execute(message, args) {
    if (!message.member.permissions.has('ManageMessages')) {
      return message.reply('You dont have permission to delete messages.');
    }

    const deleteCount = parseInt(args[0], 10);

    if (isNaN(deleteCount) || deleteCount < 1 || deleteCount > 100) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff0000)
        .setTitle('Command : purge')
        .setDescription('📌 **Format:** `Zpurge <amount>`\nExp: `Zpurge 5` or `Zp 5`')
        .setThumbnail(message.guild.iconURL({ dynamic: true }))
        .setFooter({ text: message.guild.name,
             iconURL: message.author.displayAvatarURL()     })
        .setTimestamp();

      return message.reply({ embeds: [errorEmbed] });
    }

    try {
      const fetched = await message.channel.messages.fetch({ limit: deleteCount + 1 });
      await message.channel.bulkDelete(fetched);

      const successEmbed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle('Deleted Message')
        .setDescription(`✅ Managed to delete **${deleteCount}** message.`)
        .setTimestamp();

      message.channel.send({ embeds: [successEmbed] })
        .then(msg => setTimeout(() => msg.delete().catch(() => {}), 3000));
    } catch (error) {
      console.error(error);
      message.reply('An error occurs when deleting the message.');
    }
  }
};
