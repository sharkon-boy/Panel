
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'img1',
  description: 'Cek img1 bot',
  execute(message) {
    const embed = new EmbedBuilder()
      .setColor(0xFF8C00)
      .setImage('https://media.discordapp.net/attachments/1235101083127255040/1391427613041492099/IMG_20250706_213534.jpg');

    message.channel.send({ embeds: [embed] });
  }
};
