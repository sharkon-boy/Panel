const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    // Channel ID tempat goodbye message akan dikirim
    const goodbyeChannelId = '1238330275876835371';
    const goodbyeChannel = member.guild.channels.cache.get(goodbyeChannelId);
    
    if (!goodbyeChannel) return;

    // Membuat embed goodbye message
    const goodbyeEmbed = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle(`😢 Goodbye ${member.user.username}!`)
      .setDescription(`We will miss you in ${member.guild.name}!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '📅 Join', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        { name: '⏱️ Long Joining', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
        { name: '👥 Total Members Now', value: `${member.guild.memberCount}`, inline: false }
      )
      .setImage('https://media.tenor.com/ukkWM_d6YccAAAAM/good-bye-sad-bye.gif') // URL gambar banner
      .setFooter({ text: `We hope meet again!` })
      .setTimestamp();

    // Mengirim pesan ke goodbye channel
    goodbyeChannel.send({ 
      embeds: [goodbyeEmbed] 
    });
  }
};
