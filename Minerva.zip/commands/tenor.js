const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
  name: 'tenor',
  description: 'Serching and send  GIF from Tenor',
  async execute(message, args) {
    // Jika tidak ada argumen, tampilkan petunjuk penggunaan
    if (!args.length) {
      return message.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Command: tenor')
            .setDescription('🔍 **Format**: Inpit keyword for GIF\n**Exp**: `!tenor Cat cute`')
            .setColor('#FF0000')
            .setThumbnail(message.guild?.iconURL({ dynamic: true }) || null)
            .setFooter({ 
              text: message.guild?.name || 'DM Channel', 
              iconURL: message.client.user.displayAvatarURL()
            })
            .setTimestamp()
        ]
      });
    }

    const searchTerm = args.join(' ');
    const apiKey = 'AIzaSyAYtfZ3kW-D8lBa26cejPP_2ehEPcNw8qs'; // Ganti dengan API key Tenor yang valid
    const limit = 8; // Jumlah hasil maksimal
    const url = `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(searchTerm)}&key=${apiKey}&limit=${limit}&media_filter=gif`;

    try {
      const response = await fetch(url);
      
      // Cek jika response tidak OK
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Jika tidak ada hasil
      if (!data.results || data.results.length === 0) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setTitle('🔍 No found')
              .setDescription(`No GIF was found for: \`${searchTerm}\``)
              .setColor('#FFA500')
              .setFooter({ text: 'Tenor API', iconURL: 'https://tenor.com/favicon.ico' })
          ]
        });
      }

      // Ambil hasil acak dari array
      const randomResult = data.results[Math.floor(Math.random() * data.results.length)];
      const gifUrl = randomResult.media_formats.gif.url;

      // Buat embed
      const embed = new EmbedBuilder()
        .setTitle(`🎭 GIF: ${searchTerm}`)
        .setDescription(`[See in Tenor](${randomResult.url})`)
        .setImage(gifUrl)
        .setColor('#0099FF')
        .setFooter({ 
          text: `Via Tenor API | ${message.author.username}`, 
          iconURL: message.author.displayAvatarURL() 
        })
        .setTimestamp();

      // Kirim embed
      await message.reply({ embeds: [embed] });

    } catch (error) {
      console.error('Error:', error);
      message.reply({
        embeds: [
          new EmbedBuilder()
            .setTitle('❌ Error')
            .setDescription('An error occurs when taking a GIF, Please try again later.')
            .setColor('#FF0000')
        ]
      });
    }
  }
};
