const Duel = require('../models/Duel'); // model MongoDB duel

module.exports = {
  name: 'duelTracker',
  description: 'Mendeteksi hasil duel dari Epic RPG',
  async execute(message) {
    // Hanya baca pesan dari Epic RPG bot
    if (message.author.id !== '555955826880413696') return;
    if (!message.embeds.length) return;

    const embed = message.embeds[0];
    const text = (embed.description || '') + (embed.title || '');

    // Cek apakah embed mengandung hasil duel
    const winnerMatch = text.match(/Winner:\s*<@!?(\d+)>/i);
    const loserMatch = text.match(/Loser:\s*<@!?(\d+)>/i);

    if (!winnerMatch || !loserMatch) return; // bukan hasil duel

    const winnerId = winnerMatch[1];
    const loserId = loserMatch[1];

    // Simpan hasil ke database
    await Duel.updateOne(
      { userId: winnerId },
      { $inc: { victories: 1, duels: 1 } },
      { upsert: true }
    );

    await Duel.updateOne(
      { userId: loserId },
      { $inc: { duels: 1 } },
      { upsert: true }
    );

    console.log(`🏆 Duel dicatat: Winner ${winnerId}, Loser ${loserId}`);
  }
};
