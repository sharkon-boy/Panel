module.exports = {
  name: 'kick', // atau ban, warn, dll.
  description: 'Kick user dari server',
  async execute(message, args) {
    if (!message.member.permissions.has('KickMembers')) return;

    const member = message.mentions.members.first();
    if (member) {
      await member.kick();
      message.reply(`${member.user.tag} jas been kick.`);
    } else {
      message.reply('Tag members you want to be kicked.');
    }
  }
};
