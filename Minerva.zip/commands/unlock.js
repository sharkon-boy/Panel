const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'unlock',
  description: 'Membuka kunci channel yang dikunci oleh Zlock',
  aliases: ['unlock', 'ul', 'unlockchannel'],

  async execute(message) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('❌ You need permission **Manage Channels** to lock this channel.');
    }

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('❌ I dont have permission **Manage Channels**.');
    }

    const everyone = message.guild.roles.everyone;
    try {
      await message.channel.permissionOverwrites.edit(everyone, { SendMessages: null });
      await message.reply('🔓 Channel has opened.');
    } catch (err) {
      console.error('Unlock error:', err);
      message.reply('⚠️ Failed to open channel.');
    }
  }
};
