const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');

module.exports = {
  name: 'gallerynaruto',
  aliases: ['gn', 'gallery', 'gnaruto'],
  description: 'Gallery gambar bertema Naruto (Page 1–10)',
  async execute(message) {
    const pages = [
      new EmbedBuilder()
        .setTitle("🏮 Naruto Gallery - Page 1")
        .setDescription("**Naruto Uzumaki** - The hero of Konoha 🍥")
        .setColor(0xFFA500)
        .setImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSE6XYuhMgmhQdCEbencQwxU16zBS3_ZiZjq2dkyPEN2A&s=10"),

      new EmbedBuilder()
        .setTitle("🔥 Page 2 - Sasuke Uchiha")
        .setDescription("**Sasuke Uchiha** - The avenger with eternal resolve ⚡")
        .setColor(0x0000FF)
        .setImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqJM9eQ2frR0qYw5AokiJgvh24rmAVGjXd0HbGLbyjbw&s=10"),

      new EmbedBuilder()
        .setTitle("🌸 Page 3 - Sakura Haruno")
        .setDescription("**Sakura Haruno** - The strongest kunoichi 💥")
        .setColor(0xFF69B4)
        .setImage("https://images5.alphacoders.com/644/644141.jpg"),

      new EmbedBuilder()
        .setTitle("🍃 Page 4 - Kakashi Hatake")
        .setDescription("**Kakashi Hatake** - Copy Ninja of the Sharingan 👁️")
        .setColor(0xC0C0C0)
        .setImage("https://free-3dtextureshd.com/wp-content/uploads/2025/02/571.jpg.webp"),

      new EmbedBuilder()
        .setTitle("☁️ Page 5 - Itachi Uchiha")
        .setDescription("**Itachi Uchiha** - The man who lived in the shadows 🖤")
        .setColor(0x8B0000)
        .setImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT22c9AH1hn_RgMLYSB86sWNd4YGORKP7a0QNHhXg2uGg&s=10"),

      new EmbedBuilder()
        .setTitle("💨 Page 6 - Minato Namikaze")
        .setDescription("**Minato Namikaze** - The Yellow Flash of the Leaf ⚡")
        .setColor(0xFFFF00)
        .setImage("https://e0.pxfuel.com/wallpapers/924/996/desktop-wallpaper-minato-namikaze.jpg"),

      new EmbedBuilder()
        .setTitle("🔥 Page 7 - Madara Uchiha")
        .setDescription("**Madara Uchiha** - The ghost of the Uchiha clan 👹")
        .setColor(0x7C0A02)
        .setImage("https://free-3dtextureshd.com/wp-content/uploads/2025/02/544.jpg.webp"),

      new EmbedBuilder()
        .setTitle("💀 Page 8 - Pain (Nagato)")
        .setDescription("**Pain** - ‘Those who do not understand true pain can never understand true peace.’ ⚖️")
        .setColor(0x9932CC)
        .setImage("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUYdfxACB73_ZlSAofOZuMb8oYRgIooA5xy3fZbywNMw&s=10"),

      new EmbedBuilder()
        .setTitle("🌕 Page 9 - Obito Uchiha")
        .setDescription("**Obito Uchiha** - The masked man torn between light and dark 🌀")
        .setColor(0xA0522D)
        .setImage("https://i.pinimg.com/736x/ec/ee/e5/eceee5eed7ffc57e3e39f1bf6ca0d41a.jpg"),

      new EmbedBuilder()
        .setTitle("🦊 Page 10 - Kurama")
        .setDescription("**Kurama** - The Nine-Tails Fox, sealed within Naruto 🦊🔥")
        .setColor(0xFF4500)
        .setImage("https://d.furaffinity.net/art/antrage/1680806891/1680806891.antrage_kurama.jpg")
    ];

    // Tombol navigasi
    let currentPage = 0;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('prev')
        .setLabel('◀')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('▶')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('close')
        .setLabel('❌')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await message.reply({
      embeds: [pages[currentPage]],
      components: [row]
    });

    // Kolektor tombol
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 120000 // 2 menit
    });

    collector.on('collect', i => {
      if (i.user.id !== message.author.id) {
        return i.reply({
          content: 'Hanya pengguna yang memanggil command ini yang bisa mengontrol.',
          ephemeral: true
        });
      }

      if (i.customId === 'prev') {
        currentPage = (currentPage - 1 + pages.length) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'next') {
        currentPage = (currentPage + 1) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'close') {
        i.update({ content: 'Gallery ditutup.', embeds: [], components: [] });
        collector.stop();
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};
