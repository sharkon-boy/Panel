const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping',
  description: 'Cek respons bot',
  execute(message) {
    const embed = new EmbedBuilder()
      .setColor(0x00ffcc)
      .setTitle('Pong!')
      .setDescription(`Waktu respons: ${Date.now() - message.createdTimestamp}ms`)
      .setThumbnail('https://cdn.discordapp.com/attachments/1235101083127255040/1389099682919092224/IMG_20250626_103153.jpg');

    message.channel.send({ embeds: [embed] });
  }
};
