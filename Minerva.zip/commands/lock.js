const { PermissionsBitField } = require('discord.js');

module.exports = {
  name: 'lock',
  description: 'Mengunci channel saat ini (bisa dengan durasi, contoh: Zlock 10m)',
  aliases: ['lock', 'l', 'lockchannel'],

  async execute(message, args) {
    if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('❌ You need permission **Manage Channels** to lock this channel.');
    }

    if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
      return message.reply('❌ I dont have permission **Manage Channels**.');
    }

    const everyone = message.guild.roles.everyone;
    const durationArg = args[0]; // exmple: 10m, 1h, 1d

    try {
      await message.channel.permissionOverwrites.edit(everyone, { SendMessages: false });
      await message.reply(`🔒 Channel lock${durationArg ? ` until **${durationArg}**` : ''}.`);

      if (durationArg) {
        const ms = parseDuration(durationArg);
        if (ms > 0) {
          setTimeout(async () => {
            try {
              await message.channel.permissionOverwrites.edit(everyone, { SendMessages: null });
              await message.channel.send('🔓 Channel opens automatically (Time has run out).');
            } catch (err) {
              console.error('Auto unlock error:', err);
            }
          }, ms);
        } else {
          await message.channel.send('⚠️ Unknown duration format. Use example: `5m`, `1h`, `1d`.');
        }
      }
    } catch (err) {
      console.error('Lock error:', err);
      message.reply('⚠️ Failed to lock channel.');
    }

    function parseDuration(str) {
      const regex = /^(\d+)(s|m|h|d)$/i;
      const match = str.match(regex);
      if (!match) return 0;
      const value = parseInt(match[1]);
      const unit = match[2].toLowerCase();
      const multiplier = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[unit];
      return value * multiplier;
    }
  }
};
