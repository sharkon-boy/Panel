const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');

module.exports = {
  name: 'gallerydragonball',
  aliases: ['gb', 'gdb', 'gdragonball'],
  description: 'Gallery Dragon Ball - Goku Transformations, Vegito, Gogeta',
  async execute(message) {
    const pages = [
       new EmbedBuilder()
        .setTitle("💫 Dragonball Super")
        .setDescription("**Dragonball Super** - Dragonball Super Hero  🐉")
        .setColor(0x00BFFF)
        .setImage("https://c.tenor.com/mCLQHdpPbd0AAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🌟 Page 1 - Son Goku (Base Form)")
        .setDescription("**Goku** - The Saiyan raised on Earth. Calm, pure-hearted, and always ready to train 💪")
        .setColor(0xFFA500)
        .setImage("https://c.tenor.com/lSRdL_fs7yUAAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🌌 Page 2 - Gogeta Ssj4")
        .setDescription("**Gogeta Ssj4 (Ultimate Fusion)** - Fusion ultimate from goku ssj4 and vegeta ssj4, serenity within chaos 🌠")
        .setColor(0xFFFFFF)
        .setImage("https://c.tenor.com/DKHgtGINJ3gAAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("💙 Page 3 - Vegito Blue")
        .setDescription("**Vegito (SSGSS)** - Fusion of Goku & Vegeta using Potara earrings 💥 The ultimate warrior!")
        .setColor(0x1E90FF)
        .setImage("https://c.tenor.com/wEsBRuvAnEYAAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("💥 Page 4 - Gogeta ")
        .setDescription("**Gogeta (SSJ)** - The perfect fusion born of dance, unmatched in style and power ⚡")
        .setColor(0x4169E1)
        .setImage("https://c.tenor.com/13fz033IBEMAAAAd/tenor.gif")
    ];

    // Tombol navigasi
    let currentPage = 0;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('prev')
        .setLabel('◀')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('▶')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('close')
        .setLabel('❌')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await message.reply({
      embeds: [pages[currentPage]],
      components: [row]
    });

    // Kolektor tombol
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 120000 // 2 menit
    });

    collector.on('collect', i => {
      if (i.user.id !== message.author.id) {
        return i.reply({
          content: 'Hanya pengguna yang memanggil command ini yang bisa mengontrol.',
          ephemeral: true
        });
      }

      if (i.customId === 'prev') {
        currentPage = (currentPage - 1 + pages.length) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'next') {
        currentPage = (currentPage + 1) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'close') {
        i.update({ content: 'Gallery ditutup.', embeds: [], components: [] });
        collector.stop();
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};
