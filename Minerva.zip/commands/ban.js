module.exports = {
  name: 'ban',
  description: 'Ban member',
  async execute(message, args) {
if (!message.member.permissions.has('BanMembers')) return;
      const memberBan = message.mentions.members.first();
      if (memberBan) {
        await memberBan.ban();
        message.reply(`${memberBan.user.tag} has been diban.`);
      } else {
        message.reply('Tag members you want to be banned.');
      }
}
};
