const { EmbedBuilder } = require('@discordjs/builders');
const giveMeAJoke = require('give-me-a-joke');
const lang = require('../../events/loadLanguage'); 

module.exports = {
    name: 'joke',
    description: lang.jokeCommandDescription,
    async execute(message, args) {
        const { jokeEmbedTitle, jokeError } = lang;

        try {
            giveMeAJoke.getRandomDadJoke((joke) => {
                const embed = new EmbedBuilder()
                    .setColor(0xffcc00)
                    .setTitle(jokeEmbedTitle)
                    .setDescription(joke);

                message.channel.send({ embeds: [embed] });
            });
        } catch (error) {
            console.error('An error occurred during command execution:', error);
            await message.channel.send(jokeError);
        }
    }
};
