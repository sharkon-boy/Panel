const { EmbedBuilder } = require('discord.js');
const lang = {
  friendshipDescription: "Hitung tingkat persahabatan",
  friendshipTitle: "💖 Tingkat Persahabatan",
  friendshipWith: "dan",
  friendshipRating: "memiliki tingkat persahabatan sebesar",
  friendshipFooter: "Persahabatan itu penting!",
  friendshipMentionError: "❌ Mention 2 pengguna. Contoh: Zfriendship @user1 @user2"
};

module.exports = {
  name: 'friendship',
  description: lang.friendshipDescription,
  async execute(message) {
    const mentions = message.mentions.users;

    if (mentions.size < 2) {
      return message.reply(lang.friendshipMentionError);
    }

    const user1 = mentions.at(0);
    const user2 = mentions.at(1);
    const friendshipRating = Math.floor(Math.random() * 101);

    const embed = new EmbedBuilder()
      .setColor(0x00bfff)
      .setTitle(lang.friendshipTitle)
      .setDescription(`${user1} ${lang.friendshipWith} ${user2} ${lang.friendshipRating} **${friendshipRating}%**!`)
      .setFooter({ text: lang.friendshipFooter });

    await message.channel.send({ embeds: [embed] });
  }
};
