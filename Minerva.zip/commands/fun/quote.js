const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');

GlobalFonts.registerFromPath('../../UI/fonts/inter-bold.ttf', 'Inter');

module.exports = {
    name: 'quote',
    description: 'Create a custom quote image and post it',
    usage: '<text> <author> <image URL> [created by]',
    async execute(message, args) {
        if (args.length < 3) {
            return message.reply('Please provide text, author, and image URL. Usage: `!quote <text> <author> <image URL> [created by]`');
        }

        const quoteText = args[0];
        const author = args[1];
        const bgUrl = args[2];
        const createdBy = args[3] || message.author.username;

        const width = 800;
        const height = 450;
        const canvas = createCanvas(width, height);
        const ctx = canvas.getContext('2d');

        try {
            const res = await fetch(bgUrl);
            if (!res.ok) throw new Error('Image load failed');
            const buffer = Buffer.from(await res.arrayBuffer());
            const bgImage = await loadImage(buffer);

            // Draw background
            ctx.drawImage(bgImage, 0, 0, width, height);

            // Overlay for readability
            ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
            ctx.fillRect(0, 0, width, height);

            // Stylized Quote Text
            ctx.fillStyle = 'white';
            ctx.font = '32px Inter';
            ctx.textAlign = 'center';
            wrapText(ctx, `"${quoteText}"`, width / 2, height / 2 - 60, 700, 38);

            // Author (italic)
            ctx.font = 'italic 22px Inter';
            ctx.fillText(`— ${author}`, width / 2, height / 2 + 80);

            // Created By
            ctx.font = '14px Inter';
            ctx.textAlign = 'right';
            ctx.fillStyle = 'lightgray';
            ctx.fillText(`Created by ${createdBy}`, width - 20, height - 20);

            const attachment = new AttachmentBuilder(await canvas.encode('png'), { name: 'quote.png' });
            await message.channel.send({ files: [attachment] });

        } catch (err) {
            console.error(err);
            return message.reply('❌ Failed to create quote image. Make sure the image URL is valid.');
        }
    }
};

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
            ctx.fillText(line, x, y);
            line = words[n] + ' ';
            y += lineHeight;
        } else {
            line = testLine;
        }
    }
    ctx.fillText(line, x, y);
}
