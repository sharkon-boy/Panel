const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch'); // jika belum, jalankan: npm install node-fetch
const lang = {
  factDescription: "Tampilkan fakta acak",
  factTitle: "📚 Fakta Acak",
  factError: "❌ Gagal mengambil fakta. Silakan coba lagi nanti."
};

module.exports = {
  name: 'fact',
  description: lang.factDescription,
  async execute(message) {
    const apiUrl = 'https://uselessfacts.jsph.pl/random.json?language=en';

    try {
      const response = await fetch(apiUrl);
      const data = await response.json();

      const embed = new EmbedBuilder()
        .setColor(0x0000FF)
        .setTitle(lang.factTitle)
        .setDescription(data.text)
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error('Error fetching fact:', error);
      await message.channel.send(lang.factError);
    }
  }
};
