const { EmbedBuilder } = require('discord.js');

const scrambleWord = word => {
  const letters = word.split('');
  for (let i = letters.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [letters[i], letters[j]] = [letters[j], letters[i]];
  }
  return letters.join('');
};

const words = ['apple', 'banana', 'cherry', 'grape', 'lemon', 'melon', 'peach', 'plum', 'pear'];

module.exports = {
  name: 'wordscramble',
  description: 'Main tebak-tebakan kata acak',
  async execute(message, args) {
    const word = words[Math.floor(Math.random() * words.length)];
    const scrambled = scrambleWord(word);

    const embed = new EmbedBuilder()
      .setColor('#00bfff')
      .setTitle('🧠 Word Scramble')
      .setDescription(`Tebak kata ini: **${scrambled}**`)
      .setFooter({ text: 'Ketik jawabanmu sekarang!' });

    message.channel.send({ embeds: [embed] });

    const filter = m => m.author.id === message.author.id;
    const collector = message.channel.createMessageCollector({ filter, time: 30000, max: 1 });

    collector.on('collect', m => {
      if (m.content.toLowerCase() === word.toLowerCase()) {
        m.reply('✅ Benar! Kamu berhasil!');
      } else {
        m.reply(`❌ Salah. Jawaban yang benar adalah: **${word}**`);
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        message.reply(`⏰ Waktu habis! Jawaban yang benar: **${word}**`);
      }
    });
  }
};
