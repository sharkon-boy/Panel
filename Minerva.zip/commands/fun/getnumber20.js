const { EmbedBuilder } = require('discord.js');
const cmdIcons = require('../../UI/icons/commandicons');
const activeGames = {};

module.exports = {
    name: 'getnumber20',
    description: 'A game where you have to reach the number 20 before your opponent!',
    usage: '<vsbot|vsuser> [@opponent]',
    async execute(message, args) {
        if (!message.guild) return message.reply('This command can only be used in a server!');
        
        const serverId = message.guild.id;
        const targetScore = 20;

        if (!args[0] || !['vsbot', 'vsuser'].includes(args[0].toLowerCase())) {
            return message.reply('Please specify a valid mode: `!getnumber20 vsbot` or `!getnumber20 vsuser @opponent`');
        }

        const mode = args[0].toLowerCase();
        const opponent = message.mentions.users.first() || (mode === 'vsbot' ? message.client.user : null);

        if (mode === 'vsbot' && message.mentions.users.size > 0) {
            return message.reply('You cannot mention an opponent when playing against the bot.');
        }

        if (mode === 'vsuser' && !opponent) {
            return message.reply('Please mention an opponent to play against.');
        }

        if (mode === 'vsuser' && opponent.id === message.client.user.id) {
            return message.reply('You cannot play against the bot in VS User mode. Please choose a different opponent.');
        }

        if (activeGames[serverId]) {
            return message.reply('A game is already in progress in this server! Please wait for the current game to finish.');
        }

        const startingUserId = mode === 'vsbot' ? message.author.id : 
                             Math.random() < 0.5 ? message.author.id : opponent.id;

        activeGames[serverId] = {
            gameEnded: false,
            currentTurnUserId: startingUserId,
            score: 0,
            lastMoveTime: Date.now(),
            inactivityTimer: null,
            message: message,
            opponent: opponent,
            mode: mode
        };

        const gameInstructionsEmbed = new EmbedBuilder()
            .setTitle('Game Instructions')
            .setDescription(
                `**Objective:**\nReach the number **${targetScore}** before your opponent.\n\n` +
                `**How to Play:**\n- On your turn, add **1** or **2** to the current score.\n` +
                `- The game alternates turns between you and your opponent.\n` +
                `- The first to reach **${targetScore}** wins!\n\n` +
                `**Game Rules:**\n- You can only add **1** or **2** to the score each turn.\n` +
                `- If you make an invalid move or it's not your turn, you will receive a message explaining the issue.\n` +
                `- If there is inactivity for 5 minutes, the game will end automatically.\n\n` +
                `**Example Turn:**\n` +
                `- If the current score is **5**, you can choose **6** or **7** as your move.\n` +
                `- If you choose **6**, the new score will be **6**, and it will be the opponent's turn next.\n` +
                `- Keep adding **1** or **2** until someone reaches **${targetScore}**!\n\n` +
                `Good luck and have fun!`
            )
            .setColor('#00FF00')
            .setFooter({ text: 'Type a number to start playing!' })
            .setTimestamp();

        const gameStartEmbed = new EmbedBuilder()
            .setTitle('Game Started')
            .setDescription(
                `${message.author.username} vs ${mode === 'vsbot' ? 'Bot' : opponent.username}\n` +
                `First to reach ${targetScore} wins!\n\n` +
                `It's <@${activeGames[serverId].currentTurnUserId}>'s turn!`
            )
            .setColor('#00FF00')
            .setFooter({ text: 'Type a number to play!' })
            .setTimestamp();

        await message.channel.send({ embeds: [gameInstructionsEmbed, gameStartEmbed] });

        const filter = m => [message.author.id, opponent.id].includes(m.author.id) && !isNaN(m.content) && m.content.trim() !== '';
        const collector = message.channel.createMessageCollector({ filter, time: 300000 });

        const resetInactivityTimer = () => {
            if (!activeGames[serverId] || activeGames[serverId].gameEnded) return;

            clearTimeout(activeGames[serverId].inactivityTimer);
            activeGames[serverId].inactivityTimer = setTimeout(async () => {
                if (!activeGames[serverId] || activeGames[serverId].gameEnded) return;

                activeGames[serverId].gameEnded = true;
                const endEmbed = new EmbedBuilder()
                    .setTitle('Game Ended')
                    .setDescription('The game has ended due to inactivity. No one responded in 5 minutes.')
                    .setColor('#FF0000')
                    .setFooter({ text: 'Try again later!' })
                    .setTimestamp();

                await message.channel.send({ embeds: [endEmbed] });
                delete activeGames[serverId];
            }, 300000);
        };

        const makeBotMove = () => {
            let botChoice = activeGames[serverId].score + (Math.random() < 0.5 ? 1 : 2);
            if (botChoice > targetScore) botChoice = targetScore;
            return botChoice;
        };

        const takeBotTurn = async () => {
            if (!activeGames[serverId] || activeGames[serverId].gameEnded) return;

            const botChoice = makeBotMove();
            activeGames[serverId].score = botChoice;

            await message.channel.send(`The bot chooses ${botChoice}`);

            if (activeGames[serverId].score >= targetScore) {
                activeGames[serverId].gameEnded = true;
                collector.stop();

                const winEmbed = new EmbedBuilder()
                    .setTitle('The Bot Wins!')
                    .setDescription(`The Bot reached ${targetScore} first!\n\nFinal score: ${activeGames[serverId].score}`)
                    .setColor('#FFD700')
                    .setTimestamp();

                await message.channel.send({ embeds: [winEmbed] });
                delete activeGames[serverId];
            } else {
                activeGames[serverId].currentTurnUserId = message.author.id;
                const turnEmbed = new EmbedBuilder()
                    .setTitle('Next Turn')
                    .setDescription(`It's <@${activeGames[serverId].currentTurnUserId}>'s turn! Current score: ${activeGames[serverId].score}`)
                    .setColor('#00FF00')
                    .setFooter({ text: 'Type a number to play!' })
                    .setTimestamp();

                await message.channel.send({ embeds: [turnEmbed] });
                resetInactivityTimer();
            }
        };

        const handleUserTurn = async (m) => {
            if (!activeGames[serverId] || activeGames[serverId].gameEnded) return;

            const userId = m.author.id;
            let userChoice = parseInt(m.content);
            const minNumber = activeGames[serverId].score + 1;
            const maxNumber = activeGames[serverId].score + 2;

            if (userId !== activeGames[serverId].currentTurnUserId) {
                const reply = await m.reply(`It's not your turn! Please wait for <@${activeGames[serverId].currentTurnUserId}>'s turn.`);
                setTimeout(() => reply.delete(), 10000);
                return;
            }

            if (userChoice < minNumber || userChoice > maxNumber) {
                const reply = await m.reply(`You can only add 1 or 2 to the current score. Please choose a valid number between ${minNumber} and ${maxNumber}.`);
                setTimeout(() => reply.delete(), 10000);
                return;
            }

            activeGames[serverId].score = userChoice;
            activeGames[serverId].lastMoveTime = Date.now();

            if (activeGames[serverId].score >= targetScore) {
                activeGames[serverId].gameEnded = true;
                collector.stop();

                const winEmbed = new EmbedBuilder()
                    .setTitle('Congratulations!')
                    .setDescription(`${m.author.username} reached ${targetScore} first and won the game!\n\nFinal score: ${activeGames[serverId].score}`)
                    .setColor('#FFD700')
                    .setTimestamp();

                await message.channel.send({ embeds: [winEmbed] });
                delete activeGames[serverId];
            } else {
                activeGames[serverId].currentTurnUserId = activeGames[serverId].currentTurnUserId === message.author.id ? opponent.id : message.author.id;

                const turnEmbed = new EmbedBuilder()
                    .setTitle('Next Turn')
                    .setDescription(`It's <@${activeGames[serverId].currentTurnUserId}>'s turn! Current score: ${activeGames[serverId].score}`)
                    .setColor('#00FF00')
                    .setFooter({ text: 'Type a number to play!' })
                    .setTimestamp();

                await message.channel.send({ embeds: [turnEmbed] });
                resetInactivityTimer();

                if (activeGames[serverId].mode === 'vsbot' && activeGames[serverId].currentTurnUserId === message.client.user.id) {
                    await takeBotTurn();
                }
            }
        };

        collector.on('collect', handleUserTurn);
        collector.on('end', (collected, reason) => {
            if (reason === 'time') {
                if (!activeGames[serverId] || activeGames[serverId].gameEnded) return;

                activeGames[serverId].gameEnded = true;
                const endEmbed = new EmbedBuilder()
                    .setTitle('Game Ended')
                    .setDescription('The game has ended due to inactivity. No one responded in 5 minutes.')
                    .setColor('#FF0000')
                    .setFooter({ text: 'Try again later!' })
                    .setTimestamp();

                message.channel.send({ embeds: [endEmbed] });
                delete activeGames[serverId];
            }
        });

        resetInactivityTimer();
    }
};
