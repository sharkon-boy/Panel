const { EmbedBuilder } = require('@discordjs/builders');
const lang = require('../../events/loadLanguage'); 
const cmdIcons = require('../../UI/icons/commandicons');

module.exports = {
    name: 'randomnumber',
    description: lang.randomnumCommandDescription,
    usage: '<min> <max>',
    async execute(message, args) {
        if (args.length < 2) {
            return message.reply('Please provide minimum and maximum values. Usage: `!randomnumber <min> <max>`');
        }

        const min = parseInt(args[0]);
        const max = parseInt(args[1]);

        if (isNaN(min) || isNaN(max)) {
            return message.reply(lang.randomnumError);
        }

        const [actualMin, actualMax] = min > max ? [max, min] : [min, max];
        const randomNumber = Math.floor(Math.random() * (actualMax - actualMin + 1)) + actualMin;

        const embed = new EmbedBuilder()
            .setColor(0x0000FF)
            .setTitle(lang.randomnumTitle)
            .setDescription(lang.randomnumDescription
                .replace('{min}', actualMin)
                .replace('{max}', actualMax)
                .replace('{randomNumber}', randomNumber))
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    }
};
