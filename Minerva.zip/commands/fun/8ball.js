const { EmbedBuilder } = require('discord.js');
const cmdIcons = require('../../UI/icons/commandicons');

module.exports = {
  name: '8ball',
  description: 'Menjawab pertanyaan dengan gaya magic 8-ball',
  async execute(message, args) {
    const question = args.join(' ');
    if (!question) {
      return message.reply('❓ Kamu harus memberikan pertanyaan. Contoh: `Z8ball Apakah aku ganteng?`');
    }

    const responses = [
      "🎱 It is certain.",
      "🎱 Very doubtful.",
      "🎱 Ask again later.",
      "🎱 Without a doubt.",
      "🎱 Yes, definitely.",
      "🎱 My sources say no.",
      "🎱 Outlook good.",
      "🎱 Don't count on it."
    ];

    const response = responses[Math.floor(Math.random() * responses.length)];

    const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('🎱 Magic 8-Ball')
      .setDescription(`**Pertanyaan:** ${question}\n**Jawaban:** ${response}`)
      .setFooter({ text: 'Magic 8-Ball', iconURL: cmdIcons.dotIcon });

    return message.reply({ embeds: [embed] });
  }
};
