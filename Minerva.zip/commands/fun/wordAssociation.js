const { EmbedBuilder, ChannelType, PermissionsBitField } = require('discord.js');
const cmdIcons = require('../../UI/icons/commandicons');
const lang = require('../../events/loadLanguage');

// ... (keep the same wordHints object and helper functions)

module.exports = {
    name: 'wordassociation',
    description: lang.wordAssociationDescription,
    async execute(message, args) {
        if (!message.guild) {
            return message.reply(lang.serverOnlyMessage);
        }

        const commandUser = message.author;
        let currentWord = getRandomWord();

        const botMember = await message.guild.members.fetch(message.client.user.id);
        if (!botMember) {
            return message.reply(lang.fetchBotMemberError);
        }

        const requiredPermissions = [
            PermissionsBitField.Flags.ViewChannel,
            PermissionsBitField.Flags.SendMessages,
            PermissionsBitField.Flags.ManageChannels,
        ];

        const botPermissions = botMember.permissionsIn(message.channel);
        const missingPermissions = requiredPermissions.filter(permission => !botPermissions.has(permission));

        if (missingPermissions.length > 0) {
            const permissionNames = missingPermissions.map(permission => {
                switch (permission) {
                    case PermissionsBitField.Flags.ViewChannel:
                        return lang.viewChannelsPermission;
                    case PermissionsBitField.Flags.SendMessages:
                        return lang.sendMessagesPermission;
                    case PermissionsBitField.Flags.ManageChannels:
                        return lang.manageChannelsPermission;
                    default:
                        return lang.unknownPermission;
                }
            }).join(', ');

            return message.reply(`${lang.missingPermissionsMessage} ${permissionNames}. ${lang.adjustPermissions}`);
        }

        const existingChannel = message.guild.channels.cache.find(channel => channel.name === `word-association-${commandUser.username.toLowerCase()}`);
        if (existingChannel) {
            return message.reply(`${lang.existingGameMessage} ${existingChannel}. ${lang.finishCurrentGame}`);
        }

        let tempChannel;
        try {
            tempChannel = await message.guild.channels.create({
                name: `word-association-${commandUser.username.toLowerCase()}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: message.guild.roles.everyone,
                        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages],
                    },
                    {
                        id: commandUser.id,
                        allow: [PermissionsBitField.Flags.SendMessages],
                    },
                ],
            });
        } catch (error) {
            return message.reply(lang.channelCreationError);
        }

        await tempChannel.send(`${commandUser} ${lang.gameStartMessage} \n ${lang.hintMessage} **${wordHints[currentWord]}**`);

        try {
            await commandUser.send(`${lang.wordIsMessage} **${currentWord}** ${lang.keepSecret}`);
        } catch (error) {
            await tempChannel.delete().catch(console.error);
            return message.reply(lang.dmSendError);
        }

        await message.reply(`${lang.gameStartedMessage} ${tempChannel}. ${lang.goodLuck}`);

        const filter = msg => msg.channel.id === tempChannel.id;
        const collector = tempChannel.createMessageCollector({ filter, time: 300000 });

        collector.on('collect', async msg => {
            const userWord = msg.content.trim().toLowerCase();
            const userId = msg.author.id;

            if (userId === commandUser.id) {
                if (userWord.startsWith('!')) {
                    await msg.delete().catch(console.error);
                    await msg.author.send(lang.noCommandsMessage).catch(console.error);
                    return;
                }
                return;
            }

            if (userWord.startsWith('!')) {
                if (userWord === currentWord) {
                    currentWord = getRandomWord();
                    await tempChannel.send(`${lang.goodChoiceMessage} ${msg.author}! ${lang.wordUpdatedMessage}\n${lang.hintMessage}: ${wordHints[currentWord]}`);
                    try {
                        await commandUser.send(`${lang.newWordMessage} **${currentWord}**`);
                    } catch (error) {
                        // Handle DM error if necessary
                    }
                } else {
                    await tempChannel.send(`${msg.author}, "${userWord}" ${lang.notRelatedMessage}`);
                }
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                commandUser.send(lang.noResponseMessage);
            } else {
                tempChannel.send(lang.gameEndMessage);
            }
            tempChannel.delete().catch(console.error);
        });
    }
};

function getRandomWord() {
    const words = Object.keys(wordHints);
    return words[Math.floor(Math.random() * words.length)];
}
