const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'converter',
  aliases: ['zcon', 'convert', 'con'],
  description: 'Convert HEX dan ASCII (angka/string) dengan mudah!',
  async execute(message, args) {
    if (!args[0] || !args[1]) {
      return message.reply(`❌ Contoh: 
\`zconverter hex tohex 255\` 
\`zconverter hex fromhex 48656c6c6f\`
\`zconverter ascii toascii Hello\` 
\`zconverter ascii fromascii 72 101 108 108 111\``);
    }

    const type = args[0].toLowerCase();   // hex / ascii
    const mode = args[1].toLowerCase();   // tohex, fromhex, toascii, fromascii, auto
    const value = args.slice(2).join(" ");

    let title = '🔄 | Converter';
    let description = '';
    let color = 'Blue';

    // === HEX Converter ===
    if (type === "hex") {
      if (mode === "tohex") {
        if (!isNaN(value)) {
          const number = parseInt(value);
          description = `🔢 Number **${number}** in HEX ➝ \`${number.toString(16)}\``;
        } else {
          const hex = Buffer.from(value, "utf8").toString("hex");
          description = `💬 String **${value}** dalam HEX ➝ \`${hex}\``;
        }
      }
      else if (mode === "fromhex") {
        const hexRegex = /^[0-9a-fA-F]+$/;
        if (!hexRegex.test(value)) {
          return message.reply("❌ Input must be some code hex valid (0-9, a-f).");
        }
        const decimal = parseInt(value, 16);
        description = `💻 HEX **${value}** in Desimal ➝ \`${decimal}\``;

        if (value.length % 2 === 0) {
          try {
            const str = Buffer.from(value, "hex").toString("utf8");
            if (str.match(/^[\x20-\x7E]+$/)) {
              description += `\n💬 HEX **${value}** dalam String ➝ \`${str}\``;
            }
          } catch {}
        }
      }
      else if (mode === "auto") {
        const hexRegex = /^[0-9a-fA-F]+$/;
        if (!isNaN(value)) {
          const number = parseInt(value);
          description = `🔢 Number **${number}** in HEX ➝ \`${number.toString(16)}\``;
        } else if (hexRegex.test(value)) {
          const decimal = parseInt(value, 16);
          description = `💻 HEX **${value}** in Desimal ➝ \`${decimal}\``;
          if (value.length % 2 === 0) {
            try {
              const str = Buffer.from(value, "hex").toString("utf8");
              if (str.match(/^[\x20-\x7E]+$/)) {
                description += `\n💬 HEX **${value}** dalam String ➝ \`${str}\``;
              }
            } catch {}
          }
        } else {
          const hex = Buffer.from(value, "utf8").toString("hex");
          description = `💬 String **${value}** dalam HEX ➝ \`${hex}\``;
        }
      }
      else {
        return message.reply(`❌ Mode HEX unknow! Using: \`zconverter hex tohex|fromhex|auto <value>\``);
      }
    }

    // === ASCII Converter ===
    else if (type === "ascii") {
      if (mode === "toascii") {
        const asciiCodes = value.split("").map(c => c.charCodeAt(0)).join(" ");
        description = `💬 String **${value}** dalam ASCII ➝ \`${asciiCodes}\``;
      }
      else if (mode === "fromascii") {
        const numbers = value.split(" ");
        if (!numbers.every(num => !isNaN(num))) {
          return message.reply("❌ Input must be some number ASCII separated spaces. Exp: `72 101 108 108 111`");
        }
        const text = numbers.map(num => String.fromCharCode(parseInt(num))).join("");
        description = `🔢 ASCII **${value}** dalam String ➝ \`${text}\``;
      }
      else {
        return message.reply(`❌ Mode ASCII tidak dikenal! Gunakan: \`zconverter ascii toascii|fromascii <value>\``);
      }
    }

    else {
      return message.reply("❌ Tipe tidak dikenal! Gunakan: `zconverter hex ...` atau `zconverter ascii ...`");
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(description)
      .setColor(color)
      .setFooter({ text: `Converter by ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
      .setThumbnail(message.guild.iconURL({ dynamic: true }));

    await message.reply({ embeds: [embed] });
  },
};
