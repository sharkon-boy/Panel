const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'rules',
  description: 'Display rule of server',
  async execute(message) {
    const rulesEmbed = new EmbedBuilder()
      .setColor(0xFF8C00) // Dark Orange color
      .setTitle('📜 SERVER RULES')
      .setThumbnail('https://cdn.discordapp.com/attachments/1235092583789756517/1389115859330535424/IMG_20250630_115722.jpg')
      .setDescription('**Please read and obey all the following rules to maintain mutual comfort::**')
      .addFields(
        { name: '1. Respect all members', value: 'The treatment of all members politely and respectfully..' },
        { name: '2. Negative content prohibition', value: 'Prohibited utterances of hatred, discrimination, or harassment in any form.' },
        { name: '3. Appropriate content', value: 'Take care of all conversations stay fast for all ages (PG-rated).' },
        { name: '4. Anti Spam', value: 'Prohibited spam messages, excessive tags, or promotions without permission.' },
        { name: '5. Privasi', value: 'Do not share personal information both owned by yourself and others.' },
        { name: '6. Obedient TOS Discord', value: 'You have to obey [Discord Terms of Service](https://discord.com/terms) and [Community Guidelines](https://discord.com/guidelines).' },
        { name: '7. Impersonation prohibition', value: 'It is strictly forbidden to pretend to be another member or staff.' },
        { name: '8. NSFW prohibition', value: 'Adult content (NSFW) is prohibited in all channels.' },
        { name: '9. Reporting', value: 'If you see a violation, immediately report it to the mod/admin.' },
        { name: '10. Community goals', value: 'Remember that we are here to have fun and interact in a healthy manner!' }
      )
      .setImage('https://i.pinimg.com/originals/2e/45/14/2e45149ce1f55f5fd532cf8426a9b31c.gif') // Banner rules
      .setFooter({ 
        text: `${message.guild.name} • `, 
        iconURL: message.guild.iconURL({ dynamic: true }) 
      })
      .setTimestamp();

    message.channel.send({ 
      content: '** 📢 ATTENTION ALL MEMBERS! ** ',
      embeds: [rulesEmbed] 
    });
  }
};
