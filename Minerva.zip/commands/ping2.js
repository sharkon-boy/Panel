const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ping2',
  description: 'Cek latency dan status bot',
  async execute(message) {
    // Calculate ping
    const startTime = Date.now();
    const sentMessage = await message.reply({ content: '⏳ Mengukur ping...', fetchReply: true });
    const botPing = Date.now() - startTime;
    const apiPing = message.client.ws.ping;

    // Create embed
    const pingEmbed = new EmbedBuilder()
      .setColor('#00FFCC') // Teal color
      .setTitle('🏓 Pong!')
      .setDescription(`
        **• Bot Latency:** \`${botPing}ms\`
        **• API Latency:** \`${apiPing}ms\`
        **• Uptime:** ${formatUptime(message.client.uptime)}
      `)
      .setThumbnail('https://cdn.discordapp.com/attachments/1235101083127255040/1389099682919092224/IMG_20250626_103153.jpg')
      .setFooter({
        text: `Request by: ${message.author.username}`,
        iconURL: message.author.displayAvatarURL()
      })
      .setTimestamp();

    // Edit original reply with the embed
    await sentMessage.edit({
      content: `${message.author}`, // Clean mention without extra spaces
      embeds: [pingEmbed]
    });
  }
};

// Helper function to format uptime
function formatUptime(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor((ms / (1000 * 60 * 60)) % 24);
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));

  return `\`${days}d ${hours}h ${minutes}m ${seconds}s\``;
}
