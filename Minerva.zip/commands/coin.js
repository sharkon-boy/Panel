const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'coin',
  description: 'Throw coins (1 or more)',
  execute(message, args) {
    const jumlah = parseInt(args[0]) || 1;

    if (jumlah <= 0 || jumlah > 100) {
      return message.reply('Enter the amount between 1 - 100.');
    }

    // Gambar head & tail
    const headImage = 'https://media.discordapp.net/attachments/1238693417975025704/1378067314158731334/remove.photos-removed-background_3.png';
    const tailImage = 'https://cdn.discordapp.com/attachments/1238693417975025704/1378067725737525349/remove.photos-removed-background.png';

    const hasil = [];
    let heads = 0, tails = 0;

    for (let i = 0; i < jumlah; i++) {
      const flip = Math.random() < 0.5 ? 'heads' : 'tails';
      hasil.push(flip);
      if (flip === 'heads') heads++;
      else tails++;
    }

    const embed = new EmbedBuilder()
      .setTitle('Coinflip Results')
      .setColor(0xFDBA2D)
      .setFooter({ text: `Requested by ${message.author.tag}` ,
            iconURL: message.author.displayAvatarURL()
    });

    if (jumlah === 1) {
      const singleResult = hasil[0];
      embed.setDescription(`${message.author.username} tossed 1 coin!\nAnd got **${singleResult.toUpperCase()}**!`)
        .setThumbnail(singleResult === 'heads' ? headImage : tailImage);
    } else {
      embed.setDescription(`${message.author.username} tossed **${jumlah}** coins!\nGot **${heads} heads** and **${tails} tails**!\n\n${hasil.map(r => r === 'heads' ? '🦅' : '💰').join(' ')}`)
        .setThumbnail(heads >= tails ? headImage : tailImage);
    }

    message.channel.send({ embeds: [embed] });
  }
};
