module.exports = {
  name: 'mute',
  description: 'Mute member sementara',
  async execute(message, args) {
    if (!message.member.permissions.has('ModerateMembers')) return;

    const member = message.mentions.members.first();
    const duration = parseInt(args[1]) || 10;

    if (!member) {
      return message.reply('Tag members you want to be mute.');
    }

    await member.timeout(duration * 60 * 1000);
    message.reply(`${member.user.tag} has been mute during ${duration} minutes.`);
  }
};
