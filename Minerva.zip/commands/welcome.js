const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const welcomeChannelId = '1235220228464447582';
    const welcomeChannel = member.guild.channels.cache.get(welcomeChannelId);
    if (!welcomeChannel) return;

    // 🌸 Tema 1 — Classic Green
    const theme1 = new EmbedBuilder()
      .setColor('#00ff00')
      .setTitle('🌺 Welcome to The Tank Crew 🌿')
      .setDescription(`Welcome ${member}, we hope you enjoy your stay!  
Check out <#1235092583789756517> and say hello in <#1235099920965566504>!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .setImage('https://media.tenor.com/kxtHkSHCQDMAAAAM/ninja-protocol-banner.gif')
      .setFooter({ text: `Enjoy your time in ${member.guild.name}!` })
      .setTimestamp();

    // 🌌 Tema 2 — Galaxy Blue
    const theme2 = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('🌠 Welcome Adventurer! 🌠')
      .setDescription(`✨ ${member} just arrived from the stars!  
Explore <#1235496025293193257> and join the fun!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .setImage('https://c.tenor.com/EP_XfzfTxoUAAAAC/tenor.gif')
      .setFooter({ text: 'We’re happy you’re here!' })
      .setTimestamp();

    // 🔥 Tema 3 — Red Neon
    const theme3 = new EmbedBuilder()
      .setColor('#ff0000')
      .setTitle('🔥 Welcome Warrior! 🔥')
      .setDescription(`💥 ${member}, a new challenger appears!  
Don’t forget to read <#1235092583789756517> before starting your adventure!`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .setImage('https://c.tenor.com/kKHBMAQ1s-YAAAAC/tenor.gif')
      .setFooter({ text: 'Prepare for glory!' })
      .setTimestamp();

    // 🌀 Daftar semua tema
    const themes = [theme1, theme2, theme3];

    // Pilih tema berdasarkan urutan join
    const themeIndex = (member.guild.memberCount - 1) % themes.length;
    const selectedEmbed = themes[themeIndex];

    // Kirim pesan ke channel
    await welcomeChannel.send({
      content: `${member}`,
      embeds: [selectedEmbed],
    });

    // Role otomatis (opsional)
    const defaultRoleId = '1389099081544110101';
    const defaultRole = member.guild.roles.cache.get(defaultRoleId);
    if (defaultRole) {
      try {
        await member.roles.add(defaultRole);
      } catch (error) {
        console.error('Fail to give a role:', error);
      }
    }
  },
};