const fs = require('fs');
const { EmbedBuilder } = require('discord.js');

// Fungsi untuk mengkonversi string waktu ke milidetik
function parseTime(timeStr) {
  const timeUnits = {
    'd': 24 * 60 * 60 * 1000, // hari
    'h': 60 * 60 * 1000,      // jam
    'm': 60 * 1000,           // menit
    's': 1000                 // detik
  };

  // Regex untuk mencocokkan format waktu (contoh: 1d2h30m15s)
  const timeRegex = /(\d+)([dhms])/g;
  let totalMs = 0;
  let match;
  
  while ((match = timeRegex.exec(timeStr))) {
    const value = parseInt(match[1]);
    const unit = match[2];
    totalMs += value * timeUnits[unit];
  }

  return totalMs;
}

module.exports = {
  name: 'remindrepeat',
  aliases: ['repeat', 'rr'],
  description: 'Repeating Set Set who will mention you in time',
  async execute(message, args) {
    if (args.length < 2) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff4444)
        .setTitle('❌ Format is wrong')
        .setDescription('Using format:\n`Zremindrepeat <time> <message>`\nExp:\n`Zremindrepeat 1h30m Rest in area`\n`Zrr 30m Drink water`\n`Zremindrepeat 1d12h30m15s Meeting absolute`')
        .addFields(
          { name: 'Format Time', value: 'Combined from:\n`d` = day\n`h` = hour\n`m` = minutes\n`s` = second' },
          { name: 'Contoh', value: '1d2h30m15s = 1 hari, 2 jam, 30 menit, 15 detik' }
        );
      return message.channel.send({ embeds: [errorEmbed] });
    }

    const timeStr = args[0];
    const repeatMsg = args.slice(1).join(' ');
    const repeatTime = parseTime(timeStr);

    // Validasi waktu
    if (!repeatTime || isNaN(repeatTime)) {
      const errorEmbed = new EmbedBuilder()
        .setColor(0xff4444)
        .setTitle('❌ Format Time is Wrong')
        .setDescription('Format time invalid. Using Combined :\n`d` (day), `h` (hour), `m` (minutes), `s` (second)\nExp: `1h30m`, `2d5h`, `30s`');
      return message.channel.send({ embeds: [errorEmbed] });
    }

    // Normalisasi command untuk deteksi duplikat
    function normalizeCommandName(command) {
      return command
        .replace(/[^a-zA-Z0-9\s]/g, '')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase();
    }

    const normalizedCommand = normalizeCommandName(`repeat ${repeatMsg}`);

    // Cek duplikat
    const isDuplicate = global.reminders.some(r => 
      r.userId === message.author.id && 
      r.normalizedCommand === normalizedCommand
    );

    if (isDuplicate) {
      const duplicateEmbed = new EmbedBuilder()
        .setColor(0xffbb33)
        .setTitle('Reminder already exists')
        .setDescription('You already have repeated reminder with the same message.');
      return message.channel.send({ embeds: [duplicateEmbed] });
    }

    // Simpan pengingat dengan format yang konsisten
    const reminderData = {
      userId: message.author.id,
      channelId: message.channel.id,
      message: `<@${message.author.id}> ${repeatMsg}`,
      time: Date.now() + repeatTime,
      repeatInterval: repeatTime,
      repeat: true,
      label: repeatMsg,
      commandType: 'repeat',
      normalizedCommand: normalizedCommand
    };

    global.reminders.push(reminderData);
    fs.writeFileSync('reminders.json', JSON.stringify(global.reminders, null, 2));

    // Update reminderMap
    if (!global.reminderMap.has(message.author.id)) {
      global.reminderMap.set(message.author.id, []);
    }
    global.reminderMap.get(message.author.id).push(reminderData);

    // Format waktu untuk ditampilkan
    const seconds = Math.floor((repeatTime / 1000) % 60);
    const minutes = Math.floor((repeatTime / (1000 * 60)) % 60);
    const hours = Math.floor((repeatTime / (1000 * 60 * 60)) % 24);
    const days = Math.floor(repeatTime / (1000 * 60 * 60 * 24));

    let timeDisplay = [];
    if (days > 0) timeDisplay.push(`${days} hari`);
    if (hours > 0) timeDisplay.push(`${hours} jam`);
    if (minutes > 0) timeDisplay.push(`${minutes} menit`);
    if (seconds > 0) timeDisplay.push(`${seconds} detik`);

    // Embed konfirmasi
    const confirmEmbed = new EmbedBuilder()
      .setColor(0x00cc99)
      .setTitle('⏰ Repeated reminder is stored!')
      .setDescription(`You will be mention every ${timeDisplay.join(', ')}`)
      .addFields(
        { name: 'Mesaage', value: repeatMsg },
        { name: 'Interval', value: timeDisplay.join(', ') },
        { name: 'User', value: `<@${message.author.id}>` }
      )
      .setFooter({ text: `ID: ${message.author.id}` })
      .setTimestamp();

    await message.channel.send({ embeds: [confirmEmbed] });
  }
};
