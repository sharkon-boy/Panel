const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');

module.exports = {
  name: 'galleryakatsuki',
  aliases: ['ga', 'akatsuki', 'akat'],
  description: 'Gallery gambar bertema Akatsuki (Page 1–10)',
  async execute(message) {
    const pages = [

        new EmbedBuilder()
        .setTitle("💎 Akatsuki Members")
        .setDescription("**Akatsuki** - Akatsuki is a criminal organization of the main antagonists in the Naruto series.🛡️")
        .setColor(0x000000)
        .setImage("https://c.tenor.com/n444ueYJWt4AAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🌑 Page 1 - Pain (Nagato)")
        .setDescription("**Pain (Nagato)** - 'Those who do not understand pain can never understand peace.' ⚖️")
        .setColor(0x800080)
        .setImage("https://c.tenor.com/HiiuXL9dNroAAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🌀 Page 2 - Obito Uchiha / Tobi")
        .setDescription("**Obito Uchiha (Tobi)** - The masked man who changed the world. 🌀")
        .setColor(0xA0522D)
        .setImage("https://c.tenor.com/e_tDtrTU5zkAAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🔥 Page 3 - Itachi Uchiha")
        .setDescription("**Itachi Uchiha** - The man who sacrificed everything for peace. 🖤")
        .setColor(0x8B0000)
        .setImage("https://c.tenor.com/Ba4pYZFhM1oAAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🎭 Page 4 - Kisame Hoshigaki")
        .setDescription("**Kisame Hoshigaki** - The Monster of the Hidden Mist 🌊")
        .setColor(0x1E90FF)
        .setImage("https://c.tenor.com/gWHDegjMJgQAAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("💐 Page 5 - Konan")
        .setDescription("**Konan** - The Angel of Amegakure 🌸")
        .setColor(0x87CEEB)
        .setImage("https://c.tenor.com/yt7c7v8D5m0AAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🦜 Page 6 - Deidara")
        .setDescription("**Deidara** - 'Art is an explosion!' 💣")
        .setColor(0xFFD700)
        .setImage("https://c.tenor.com/OtiPCB7gK5cAAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("💀 Page 7 - Hidan")
        .setDescription("**Hidan** - The immortal Jashinist ⛓️")
        .setColor(0xC0C0C0)
        .setImage("https://c.tenor.com/118BBsiGfXQAAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🪓 Page 8 - Kakuzu")
        .setDescription("**Kakuzu** - The man who kills for money 💰")
        .setColor(0x006400)
        .setImage("https://c.tenor.com/BnhyKJOGn_4AAAAC/tenor.gif"),

      new EmbedBuilder()
        .setTitle("💣 Page 9 - Sasori")
        .setDescription("**Sasori** - The puppet master who turned himself into art 🎭")
        .setColor(0xCD5C5C)
        .setImage("https://c.tenor.com/eRJNoO5TaMUAAAAd/tenor.gif"),

      new EmbedBuilder()
        .setTitle("🐍 Page 10 - Orochimaru")
        .setDescription("**Orochimaru** - The fallen Sannin obsessed with immortality 🐍")
        .setColor(0x4B0082)
        .setImage("https://c.tenor.com/b5hN07Nmv9gAAAAC/tenor.gif")
    ];

    // Tombol navigasi
    let currentPage = 0;
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('prev')
        .setLabel('◀')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('▶')
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('close')
        .setLabel('❌')
        .setStyle(ButtonStyle.Danger)
    );

    const msg = await message.reply({
      embeds: [pages[currentPage]],
      components: [row]
    });

    // Kolektor tombol
    const collector = msg.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 120000 // 2 menit
    });

    collector.on('collect', i => {
      if (i.user.id !== message.author.id) {
        return i.reply({
          content: 'Hanya pengguna yang memanggil command ini yang bisa mengontrol.',
          ephemeral: true
        });
      }

      if (i.customId === 'prev') {
        currentPage = (currentPage - 1 + pages.length) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'next') {
        currentPage = (currentPage + 1) % pages.length;
        i.update({ embeds: [pages[currentPage]], components: [row] });
      } else if (i.customId === 'close') {
        i.update({ content: 'Gallery ditutup.', embeds: [], components: [] });
        collector.stop();
      }
    });

    collector.on('end', () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};
