const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'server',
  description: 'Display info about this server',
  execute(message) {
    const { guild } = message;

    const embed = new EmbedBuilder()
      .setTitle(`Information Server: ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true }))
      .addFields(
        { name: 'Name Server', value: guild.name, inline: true },
        { name: 'ID', value: guild.id, inline: true },
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Number of members.', value: `${guild.memberCount}`, inline: true },
        { name: 'Date made', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: false }
      )
      .setColor('Green');

    message.reply({ embeds: [embed] });
  }
};
