const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');

module.exports = {
  name: 'tictactoe',
  aliases: ['tic', 'ttt', 'oxo'],
  description: 'Main Tic Tac Toe pakai tombol interaktif!',

  async execute(message) {
    const player1 = message.author;
    let player2 = null;

    const joinButton = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('join_game')
        .setLabel('✅ Join')
        .setStyle(ButtonStyle.Success)
    );

    const embed = new EmbedBuilder()
      .setColor(0x00bfff)
      .setTitle('🎮 Tic Tac Toe')
      .setDescription(`${player1} memulai game. Klik ✅ untuk bergabung!`);

    const msg = await message.channel.send({ embeds: [embed], components: [joinButton] });

    const collector = msg.createMessageComponentCollector({
      time: 30000,
      filter: i => !i.user.bot
    });

    collector.on('collect', async i => {
      if (i.customId === 'join_game') {
        if (i.user.id === player1.id) {
          return i.reply({ content: '❌ Kamu sudah jadi player 1.', ephemeral: true });
        }
        player2 = i.user;
        collector.stop();

        await i.update({
          embeds: [embed.setDescription(`🎉 ${player2} telah bergabung!\nGame dimulai...`)],
          components: []
        });

        return startGame(msg, player1, player2);
      }
    });

    collector.on('end', collected => {
      if (!player2) {
        msg.edit({
          embeds: [embed.setDescription('❌ Tidak ada yang join. Game dibatalkan.')],
          components: []
        });
      }
    });

    // Game logic setelah 2 player terkumpul
    async function startGame(msg, player1, player2) {
      const board = Array(9).fill(null);
      let turn = 0;
      let gameOver = false;

      const getSymbol = t => (t % 2 === 0 ? '❌' : '⭕');
      const getCurrentPlayer = () => (turn % 2 === 0 ? player1 : player2);

      const createButtons = () => {
        const rows = [];
        for (let i = 0; i < 3; i++) {
          const row = new ActionRowBuilder();
          for (let j = 0; j < 3; j++) {
            const idx = i * 3 + j;
            row.addComponents(
              new ButtonBuilder()
                .setCustomId(idx.toString())
                .setLabel(board[idx] ? board[idx] : (idx + 1).toString())
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(board[idx] !== null || gameOver)
            );
          }
          rows.push(row);
        }
        return rows;
      };

      const embed = new EmbedBuilder()
        .setColor(0x00bfff)
        .setTitle('🎮 Tic Tac Toe')
        .setDescription(`Giliran: ${getCurrentPlayer()}`);

      const gameMsg = await msg.channel.send({
        embeds: [embed],
        components: createButtons()
      });

      const gameCollector = gameMsg.createMessageComponentCollector({
        time: 120000
      });

      gameCollector.on('collect', async interaction => {
        if (interaction.user.id !== getCurrentPlayer().id) {
          return interaction.reply({ content: '⏳ Bukan giliranmu!', ephemeral: true });
        }

        const idx = parseInt(interaction.customId);
        if (board[idx] !== null || gameOver) {
          return interaction.reply({ content: '❌ Posisi tidak valid.', ephemeral: true });
        }

        board[idx] = getSymbol(turn);
        turn++;

        const winner = checkWinner(board);
        if (winner) {
          gameOver = true;
          gameCollector.stop();
          const winEmbed = EmbedBuilder.from(embed).setDescription(`🎉 ${interaction.user} menang!`);
          return interaction.update({
            embeds: [winEmbed],
            components: createButtons()
          });
        }

        if (turn >= 9) {
          gameOver = true;
          gameCollector.stop();
          const drawEmbed = EmbedBuilder.from(embed).setDescription('🤝 Seri!');
          return interaction.update({
            embeds: [drawEmbed],
            components: createButtons()
          });
        }

        embed.setDescription(`Giliran: ${getCurrentPlayer()}`);
        await interaction.update({
          embeds: [embed],
          components: createButtons()
        });
      });

      gameCollector.on('end', () => {
        if (!gameOver) {
          gameMsg.edit({
            content: '⏰ Waktu habis. Game dibatalkan.',
            components: []
          });
        }
      });

      function checkWinner(b) {
        const lines = [
          [0, 1, 2],
          [3, 4, 5],
          [6, 7, 8],
          [0, 3, 6],
          [1, 4, 7],
          [2, 5, 8],
          [0, 4, 8],
          [2, 4, 6]
        ];
        return lines.some(([a, b_, c]) => b[a] && b[a] === b[b_] && b[a] === b[c]);
      }
    }
  }
};
