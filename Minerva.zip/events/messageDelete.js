// file: events/messageDelete.js
const { Events } = require('discord.js');

module.exports = {
  name: Events.MessageDelete,
  async execute(message) {
    // Cek kalau pesan dari user biasa, bukan bot
    if (!message.guild || message.author.bot) return;

    // Cek apakah ada mention
    if (message.mentions.users.size > 0 || message.mentions.roles.size > 0 || message.mentions.everyone) {
      const mentionList = message.mentions.users.map(u => `<@${u.id}>`).join(', ') || 
                          message.mentions.roles.map(r => `<@&${r.id}>`).join(', ') ||
                          (message.mentions.everyone ? '@everyone' : '');

      // Kirim peringatan ghost ping
      message.channel.send({
        content: `👻 **Ghost ping terdeteksi!**
**Pelaku:** ${message.author.tag}
**Mention:** ${mentionList}`
      });
    }
  }
};
