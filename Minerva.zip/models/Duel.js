const mongoose = require('mongoose');

const duelSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  victories: { type: Number, default: 0 },
  duels: { type: Number, default: 0 }
});

module.exports = mongoose.model('Duel', duelSchema);
