const mongoose = require('mongoose');

const reminderSchema = new mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    channelId: {
        type: String,
        required: true
    },
    task: {
        type: String,
        required: true
    },
    remindAt: {
        type: Date,
        required: true
    }
});

module.exports = mongoose.model('Reminder', reminderSchema);
