// reminderChecker.js — karena file ini 1 folder dengan Reminder.js
const Reminder = require('./Reminder');

async function checkReminders(client) {
    const now = new Date();
    const reminders = await Reminder.find({ remindAt: { $lte: now } });

    for (const reminder of reminders) {
        try {
            const channel = await client.channels.fetch(reminder.channelId);
            if (channel) {
                await channel.send(`🔔 <@${reminder.userId}>, waktunya untuk **"${reminder.task}"**!`);
            }
        } catch (err) {
            console.error('❌ Gagal mengirim reminder:', err);
        }

        await Reminder.deleteOne({ _id: reminder._id });
    }
}

function startReminderLoop(client) {
    setInterval(() => checkReminders(client), 10 * 1000); // cek setiap 10 detik
}

module.exports = startReminderLoop;
