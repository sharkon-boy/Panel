// mongodb.js
const mongoose = require('mongoose');
let reconnecting = false; // biar nggak spam reconnect

async function connectToDatabase() {
  try {
    if (reconnecting) return; // kalau sedang reconnect, hentikan
    reconnecting = true;

    console.log('[ DATABASE ] ⏳ Connecting to MongoDB...');

    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 10000, // max tunggu 10 detik
      socketTimeoutMS: 45000,          // timeout 45 detik
    });

    console.log('[ DATABASE ] ✅ MongoDB connected successfully');
    reconnecting = false;
  } catch (err) {
    console.error('[ DATABASE ] ❌ Connection failed:', err.message);
    reconnecting = false;

    // Ulangi koneksi hanya setiap 30 detik, bukan terus-terusan
    setTimeout(connectToDatabase, 30000);
  }

  // Kalau koneksi tiba-tiba putus
  mongoose.connection.on('disconnected', () => {
    console.warn('[ DATABASE ] ⚠️ MongoDB disconnected. Retrying in 30s...');
    setTimeout(connectToDatabase, 30000);
  });

  // Tangkap error runtime dari Mongoose
  mongoose.connection.on('error', err => {
    console.error('[ DATABASE ] MongoDB runtime error:', err.message);
  });
}

module.exports = { connectToDatabase };
